import 'package:flutter/material.dart';

const plum = Color(0xFF4A2147);
const ink = Color(0xFF241727);
const coral = Color(0xFFD96E83);
const blush = Color(0xFFFFF0F3);
const blushStrong = Color(0xFFFFD6DF);
const green = Color(0xFF1C8A68);
const greenSoft = Color(0xFFE3F4ED);
const gold = Color(0xFFC39A45);
const muted = Color(0xFF8C7B87);
const border = Color(0xFFF1E6E9);
const background = Color(0xFFFFF9F7);
const sosRed = Color(0xFFD95063);
