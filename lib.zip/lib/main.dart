import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'screens/chatbot_tab.dart';
import 'screens/home_tab.dart';
import 'screens/insights_tab.dart';
import 'screens/profile_tab.dart';
import 'screens/registration_screen.dart';
import 'screens/safe_paths_tab.dart';
import 'services/live_safety_service.dart';
import 'theme.dart';

void main() {
  runApp(const SafeHerApp());
}

class SafeHerApp extends StatelessWidget {
  const SafeHerApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'SafeHer',
      theme: ThemeData(
        useMaterial3: true,
        scaffoldBackgroundColor: background,
        colorScheme: ColorScheme.fromSeed(seedColor: plum),
        fontFamily: 'sans',
      ),
      home: const AppRoot(),
    );
  }
}

/// Decides whether to show the first-launch registration form or the app
/// itself, based on whether registration has been completed before.
class AppRoot extends StatefulWidget {
  const AppRoot({super.key});

  @override
  State<AppRoot> createState() => _AppRootState();
}

class _AppRootState extends State<AppRoot> {
  bool? _registered;

  @override
  void initState() {
    super.initState();
    _checkRegistration();
  }

  Future<void> _checkRegistration() async {
    final prefs = await SharedPreferences.getInstance();
    if (!mounted) return;
    setState(() => _registered = prefs.getBool('registered') ?? false);
  }

  void _onRegistrationComplete() {
    setState(() => _registered = true);
  }

  @override
  Widget build(BuildContext context) {
    if (_registered == null) {
      return const Scaffold(backgroundColor: background, body: Center(child: CircularProgressIndicator(color: plum)));
    }
    if (_registered == false) {
      return RegistrationScreen(onComplete: _onRegistrationComplete);
    }
    return const AppShell();
  }
}

class AppShell extends StatefulWidget {
  const AppShell({super.key});

  @override
  State<AppShell> createState() => _AppShellState();
}

class _AppShellState extends State<AppShell> {
  int selectedIndex = 0;

  @override
  void initState() {
    super.initState();
    // Live GPS-driven safety reading for the Insights tab.
    LiveSafetyService.start();
  }

  void goTo(int index) {
    setState(() => selectedIndex = index);
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      HomeTab(onPlan: () => goTo(1), onInsights: () => goTo(3)),
      const SafePathsTab(),
      const ChatbotTab(),
      const InsightsTab(),
      const ProfileTab(),
    ];
    return Scaffold(
      body: IndexedStack(index: selectedIndex, children: pages),
      bottomNavigationBar: NavigationBar(
        selectedIndex: selectedIndex,
        onDestinationSelected: goTo,
        backgroundColor: Colors.white,
        indicatorColor: blushStrong,
        height: 74,
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home_rounded), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.map_outlined), selectedIcon: Icon(Icons.map_rounded), label: 'Safest paths'),
          NavigationDestination(icon: Icon(Icons.smart_toy_outlined), selectedIcon: Icon(Icons.smart_toy_rounded), label: 'Assistant'),
          NavigationDestination(icon: Icon(Icons.bar_chart_outlined), selectedIcon: Icon(Icons.bar_chart_rounded), label: 'Insights'),
          NavigationDestination(icon: Icon(Icons.person_outline_rounded), selectedIcon: Icon(Icons.person_rounded), label: 'Profile'),
        ],
      ),
    );
  }
}