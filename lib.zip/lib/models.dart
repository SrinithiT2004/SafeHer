import 'package:flutter/material.dart';
import 'package:latlong2/latlong.dart';

/// A safety haven (police station, hospital, or 24-hour venue) discovered
/// near a route via OpenStreetMap's Overpass API.
class Haven {
  const Haven({required this.name, required this.type, required this.point});

  final String name;
  final String type; // 'police', 'hospital', 'community'
  final LatLng point;

  IconData get icon {
    switch (type) {
      case 'police':
        return Icons.local_police_outlined;
      case 'hospital':
        return Icons.local_hospital_outlined;
      default:
        return Icons.storefront_outlined;
    }
  }
}

/// A real, routable path between two points, generated live from OSRM,
/// annotated with a heuristic safety score and any havens found nearby.
class SafeRoute {
  const SafeRoute({
    required this.id,
    required this.name,
    required this.subtitle,
    required this.distanceMeters,
    required this.durationSeconds,
    required this.safetyScore,
    required this.havens,
    required this.color,
    required this.points,
    required this.steps,
  });

  final String id;
  final String name;
  final String subtitle;
  final double distanceMeters;
  final double durationSeconds;
  final int safetyScore;
  final List<Haven> havens;
  final Color color;
  final List<LatLng> points;
  final List<String> steps;

  String get distanceLabel => distanceMeters >= 1000 ? '${(distanceMeters / 1000).toStringAsFixed(1)} km' : '${distanceMeters.round()} m';

  String get durationLabel {
    final minutes = (durationSeconds / 60).round();
    if (minutes < 1) return '<1 min';
    if (minutes < 60) return '$minutes min';
    final hours = minutes ~/ 60;
    final remMinutes = minutes % 60;
    return '${hours}h ${remMinutes}min';
  }
}

/// A tappable follow-up button attached to a bot message (e.g. "Open full
/// map"), so the chatbot can hand the user off to a richer view instead of
/// just describing where to find it.
class ChatAction {
  const ChatAction({required this.label, required this.onTap, this.icon});

  final String label;
  final IconData? icon;
  final VoidCallback onTap;
}

/// A single message in the in-app safety chatbot.
///
/// Bot messages can carry real results — a fetched [route] or nearby
/// [havens] to preview inline, plus [actions] the user can tap — rather than
/// only text instructions.
class ChatMessage {
  final String text;
  final bool fromUser;
  final DateTime time;
  final SafeRoute? route;
  final List<Haven>? havens;

  /// Map center to use when previewing [havens] (which, unlike a [route],
  /// have no polyline to derive a center from).
  final LatLng? mapCenter;
  final List<ChatAction>? actions;

  ChatMessage({
    required this.text,
    required this.fromUser,
    DateTime? time,
    this.route,
    this.havens,
    this.mapCenter,
    this.actions,
  }) : time = time ?? DateTime.now();
}
