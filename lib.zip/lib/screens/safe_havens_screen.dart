import 'package:flutter/material.dart';
import 'package:latlong2/latlong.dart';
import 'package:url_launcher/url_launcher.dart';

import '../models.dart';
import '../services/location_service.dart';
import '../services/routing_service.dart';
import '../theme.dart';
import '../widgets/route_map.dart';
import '../widgets/shared_widgets.dart';

/// Shows real safety havens (police stations, hospitals, pharmacies) near a
/// point, pinned on a live OpenStreetMap map. If [center] isn't given, the
/// screen fetches the device's current GPS position itself.
///
/// The search radius isn't pinned to one fixed distance: by default it
/// starts small and automatically expands until enough havens are found (or
/// a sensible max is hit), so sparse areas still get a useful answer. The
/// person can also override it with a fixed radius via the chips below the
/// map.
class SafeHavensScreen extends StatefulWidget {
  const SafeHavensScreen({super.key, this.center});

  final LatLng? center;

  @override
  State<SafeHavensScreen> createState() => _SafeHavensScreenState();
}

class _SafeHavensScreenState extends State<SafeHavensScreen> {
  static const _distance = Distance();
  static const _radiusOptions = <double?>[null, 1000, 3000, 5000, 10000];

  bool loading = true;
  String? error;
  LatLng? center;
  List<Haven> havens = const [];
  double radiusUsed = 1000;

  /// null = auto-expanding search. A value = fixed radius the person chose.
  double? manualRadius;

  @override
  void initState() {
    super.initState();
    _load();
  }

  String _radiusLabel(double? meters) {
    if (meters == null) return 'Auto';
    return meters >= 1000 ? '${(meters / 1000).toStringAsFixed(meters % 1000 == 0 ? 0 : 1)} km' : '${meters.round()} m';
  }

  Future<void> _load() async {
    setState(() {
      loading = true;
      error = null;
    });

    LatLng? point = widget.center ?? center;

    if (point == null) {
      final position = await LocationService.currentPosition();
      if (!mounted) return;

      if (position == null) {
        final result = await LocationService.ensurePermission();
        if (!mounted) return;
        setState(() {
          loading = false;
          error = LocationService.messageFor(result).isEmpty
              ? 'Could not get your current location. Make sure GPS is enabled and try again.'
              : LocationService.messageFor(result);
        });
        return;
      }
      point = LatLng(position.latitude, position.longitude);
    }

    try {
      List<Haven> found;
      double usedRadius;

      if (manualRadius != null) {
        found = await RoutingService.fetchNearbyHavens(point, radiusMeters: manualRadius!);
        usedRadius = manualRadius!;
      } else {
        final result = await RoutingService.fetchNearbyHavensAdaptive(point);
        found = result.havens;
        usedRadius = result.radiusMeters;
      }

      found.sort((a, b) => _distance(point!, a.point).compareTo(_distance(point, b.point)));

      if (!mounted) return;
      setState(() {
        center = point;
        havens = found;
        radiusUsed = usedRadius;
        loading = false;
      });
    } catch (_) {
      if (!mounted) return;
      setState(() {
        center = point;
        loading = false;
        error = "Couldn't reach the safety-havens service. Check your connection and try again.";
      });
    }
  }

  void _selectRadius(double? meters) {
    if (manualRadius == meters) return;
    setState(() => manualRadius = meters);
    _load();
  }

  String _distanceLabel(Haven haven) {
    if (center == null) return '';
    final meters = _distance(center!, haven.point);
    return meters >= 1000 ? '${(meters / 1000).toStringAsFixed(1)} km away' : '${meters.round()} m away';
  }

  Future<void> _openInMaps(Haven haven) async {
    final lat = haven.point.latitude;
    final lon = haven.point.longitude;
    final uri = Uri.parse('https://www.openstreetmap.org/?mlat=$lat&mlon=$lon#map=19/$lat/$lon');
    await launchUrl(uri, mode: LaunchMode.externalApplication);
  }

  String _typeLabel(String type) {
    switch (type) {
      case 'police':
        return 'Police';
      case 'hospital':
        return 'Hospital';
      default:
        return 'Pharmacy';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: background,
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(12, 8, 20, 6),
              child: Row(
                children: [
                  IconButton(
                    onPressed: () => Navigator.pop(context),
                    icon: const Icon(Icons.arrow_back_rounded, color: ink),
                  ),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text('SAFE HAVENS', style: TextStyle(color: muted, fontSize: 11, fontWeight: FontWeight.w700, letterSpacing: 1)),
                        Text(
                          loading ? 'Finding places near you…' : '${havens.length} within ${_radiusLabel(radiusUsed)}',
                          style: const TextStyle(color: ink, fontSize: 19, fontWeight: FontWeight.w700),
                        ),
                      ],
                    ),
                  ),
                  IconButton(onPressed: _load, icon: const Icon(Icons.refresh_rounded, color: plum)),
                ],
              ),
            ),
            SizedBox(
              height: 260,
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(20),
                  child: RouteMapView(
                    liveLatLng: center,
                    havens: havens,
                    loading: loading,
                    initialZoom: 15,
                    emptyHint: error == null ? null : 'Location unavailable',
                  ),
                ),
              ),
            ),
            const SizedBox(height: 12),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: SizedBox(
                height: 34,
                child: ListView.separated(
                  scrollDirection: Axis.horizontal,
                  itemCount: _radiusOptions.length,
                  separatorBuilder: (_, __) => const SizedBox(width: 8),
                  itemBuilder: (context, i) {
                    final option = _radiusOptions[i];
                    final selected = manualRadius == option;
                    return ChoiceChip(
                      label: Text(_radiusLabel(option), style: TextStyle(fontSize: 11.5, fontWeight: FontWeight.w700, color: selected ? Colors.white : plum)),
                      selected: selected,
                      onSelected: (_) => _selectRadius(option),
                      selectedColor: plum,
                      backgroundColor: blush,
                      side: BorderSide.none,
                      visualDensity: VisualDensity.compact,
                    );
                  },
                ),
              ),
            ),
            const SizedBox(height: 8),
            Expanded(
              child: ListView(
                padding: const EdgeInsets.fromLTRB(20, 0, 20, 24),
                children: [
                  if (error != null)
                    SoftCard(
                      color: const Color(0xFFFFE8EC),
                      child: Row(
                        children: [
                          const Icon(Icons.error_outline, color: sosRed, size: 18),
                          const SizedBox(width: 8),
                          Expanded(child: Text(error!, style: const TextStyle(color: Color(0xFF9A2E3E), fontSize: 12))),
                        ],
                      ),
                    ),
                  if (!loading && error == null && havens.isEmpty)
                    SoftCard(
                      color: blush,
                      child: Row(
                        children: [
                          const Icon(Icons.shield_outlined, color: plum, size: 20),
                          const SizedBox(width: 10),
                          Expanded(
                            child: Text(
                              'No police stations, hospitals, or pharmacies were found within ${_radiusLabel(radiusUsed)} of your position. Try a wider radius above.',
                              style: const TextStyle(color: plum, fontSize: 12, height: 1.4),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ...havens.map((haven) => Padding(
                        padding: const EdgeInsets.only(bottom: 8),
                        child: SoftCard(
                          child: Row(
                            children: [
                              SoftIcon(icon: haven.icon, color: haven.type == 'police' ? plum : (haven.type == 'hospital' ? sosRed : green)),
                              const SizedBox(width: 11),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(haven.name, style: const TextStyle(color: ink, fontSize: 13, fontWeight: FontWeight.w700)),
                                    const SizedBox(height: 3),
                                    Text('${_typeLabel(haven.type)} · ${_distanceLabel(haven)}', style: const TextStyle(color: muted, fontSize: 11)),
                                  ],
                                ),
                              ),
                              IconButton(
                                tooltip: 'Open pinned location in Maps',
                                onPressed: () => _openInMaps(haven),
                                icon: const Icon(Icons.pin_drop_outlined, color: coral),
                              ),
                            ],
                          ),
                        ),
                      )),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
