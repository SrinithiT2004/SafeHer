
import 'dart:async';

import 'package:flutter/material.dart';
import 'package:latlong2/latlong.dart';

import '../models.dart';
import '../services/location_service.dart';
import '../services/routing_service.dart';
import '../services/safety_stats_service.dart';
import '../theme.dart';
import '../widgets/route_map.dart';
import '../widgets/route_option.dart';
import '../widgets/shared_widgets.dart';

class SafePathsTab extends StatefulWidget {
  const SafePathsTab({super.key});

  @override
  State<SafePathsTab> createState() => _SafePathsTabState();
}

class _SafePathsTabState extends State<SafePathsTab> {
  // Start with empty fields; users choose their own start and destination.
  final sourceController = TextEditingController();

  final destinationController = TextEditingController();

  Timer? _debounce;

  bool loading = false;
  String? error;

  List<SafeRoute> routes = [];

  String? selectedId;

  bool guiding = false;
  int step = 0;

  LatLng? liveLatLng;

  @override
  void initState() {
    super.initState();

    sourceController.addListener(_onInputChanged);
    destinationController.addListener(_onInputChanged);

    // Routing is triggered only when the user types or taps.
    // It does not automatically make a network request on launch.
  }

  @override
  void dispose() {
    _debounce?.cancel();
    sourceController.dispose();
    destinationController.dispose();
    super.dispose();
  }

  void _onInputChanged() {
    _debounce?.cancel();

    // Clear stale routes as soon as either endpoint is removed or changed.
    if (sourceController.text.trim().isEmpty ||
        destinationController.text.trim().isEmpty) {
      if (mounted) {
        setState(() {
          routes = [];
          selectedId = null;
          guiding = false;
          step = 0;
          loading = false;
          error = null;
        });
      }
      return;
    }

    _debounce = Timer(
      const Duration(milliseconds: 700),
      _search,
    );
  }

  Future<void> _useCurrentLocation() async {
    final position = await LocationService.currentPosition();

    if (!mounted) return;

    if (position == null) {
      final result = await LocationService.ensurePermission();

      // Important:
      // The await above may cause this widget to be removed.
      if (!mounted) return;

      final message = LocationService.messageFor(result);

      showAppDialog(
        context,
        'Location unavailable',
        message.isEmpty
            ? 'The phone could not get a GPS position. Make sure GPS is enabled and try again.'
            : message,
      );

      return;
    }

    if (!mounted) return;

    setState(() {
      liveLatLng = LatLng(
        position.latitude,
        position.longitude,
      );

      sourceController.text = 'My location';
    });

    _search();
  }

  Future<void> _search() async {
    final source = sourceController.text.trim();
    final destination = destinationController.text.trim();

    if (source.isEmpty || destination.isEmpty) {
      if (!mounted) return;

      setState(() {
        loading = false;
        routes = [];
        selectedId = null;
        guiding = false;
        step = 0;
        error = source.isEmpty && destination.isEmpty
            ? 'Please enter the starting location and destination.'
            : source.isEmpty
                ? 'Please enter a starting location.'
                : 'Please enter a destination.';
      });
      return;
    }

    if (!mounted) return;

    setState(() {
      loading = true;
      error = null;
    });

    try {
      final LatLng from;

      if (source.toLowerCase() == 'my location' &&
          liveLatLng != null) {
        from = liveLatLng!;
      } else {
        from = await RoutingService.geocode(source);
      }

      if (!mounted) return;

      final to =
          await RoutingService.geocode(destination);

      if (!mounted) return;

      final results = await RoutingService.fetchRoutes(
        from: from,
        to: to,
        fromLabel: source,
        toLabel: destination,
      );

      if (!mounted) return;

      setState(() {
        routes = results;
        selectedId =
            results.isNotEmpty ? results.first.id : null;
        guiding = false;
        step = 0;
        loading = false;
      });
    } on RoutingException catch (e) {
      if (!mounted) return;

      setState(() {
        loading = false;
        error = e.message;
      });
    } catch (_) {
      if (!mounted) return;

      setState(() {
        loading = false;
        error =
            "Couldn't reach the routing service. Check your connection and try again.";
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final active = routes.firstWhere(
      (r) => r.id == selectedId,
      orElse: () =>
          routes.isNotEmpty ? routes.first : _placeholder(),
    );

    final hasRoutes = routes.isNotEmpty;

    return AppScroll(
      children: [
        const Header(
          eyebrow: 'ROUTE PLANNER',
          title: 'Safest paths',
          icon: Icons.shield_outlined,
        ),

        const Text(
          'Real, live-routed paths — ranked by directness and safety havens nearby, not just travel time.',
          style: TextStyle(
            color: muted,
            fontSize: 13,
            height: 1.45,
          ),
        ),

        SoftCard(
          child: Column(
            children: [
              RouteTextField(
                label: 'FROM',
                controller: sourceController,
                markerColor: plum,
                suffix: IconButton(
                  tooltip: 'Use my current location',
                  onPressed: _useCurrentLocation,
                  icon: const Icon(
                    Icons.my_location_rounded,
                    size: 18,
                    color: plum,
                  ),
                ),
              ),

              const RouteConnector(),

              RouteTextField(
                label: 'TO',
                controller: destinationController,
                markerColor: coral,
              ),

              const SizedBox(height: 15),

              SizedBox(
                width: double.infinity,
                child: FilledButton.icon(
                  onPressed: loading ? null : _search,
                  icon: loading
                      ? const SizedBox(
                          width: 14,
                          height: 14,
                          child:
                              CircularProgressIndicator(
                            strokeWidth: 2,
                            color: Colors.white,
                          ),
                        )
                      : const Icon(
                          Icons.search,
                          size: 16,
                        ),
                  label: Text(
                    loading
                        ? 'Finding safer paths…'
                        : 'Find safer paths',
                  ),
                  style: FilledButton.styleFrom(
                    backgroundColor: plum,
                    padding:
                        const EdgeInsets.symmetric(
                      vertical: 13,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),

        const SizedBox(height: 4),

        Row(
          mainAxisAlignment:
              MainAxisAlignment.spaceBetween,
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            const Column(
              crossAxisAlignment:
                  CrossAxisAlignment.start,
              children: [
                Text(
                  'Routes for your trip',
                  style: TextStyle(
                    color: ink,
                    fontSize: 17,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                SizedBox(height: 3),
                Text(
                  'Live from OpenStreetMap routing',
                  style: TextStyle(
                    color: muted,
                    fontSize: 11,
                  ),
                ),
              ],
            ),

            Container(
              decoration: BoxDecoration(
                color: blush,
                borderRadius:
                    BorderRadius.circular(10),
              ),
              padding:
                  const EdgeInsets.symmetric(
                horizontal: 9,
                vertical: 6,
              ),
              child: const Row(
                children: [
                  Icon(
                    Icons.tune,
                    size: 12,
                    color: coral,
                  ),
                  SizedBox(width: 5),
                  Text(
                    'Safest',
                    style: TextStyle(
                      color: coral,
                      fontSize: 10,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),

        const SizedBox(height: 10),

        SizedBox(
          height: 250,
          child: RouteMapView(
            route: hasRoutes ? active : null,
            liveLatLng: liveLatLng,
            loading: loading,
            emptyHint:
                'Enter a start and destination above',
          ),
        ),

        const SizedBox(height: 10),

        if (error != null)
          SoftCard(
            color: const Color(0xFFFFE8EC),
            child: Row(
              children: [
                const Icon(
                  Icons.error_outline,
                  color: sosRed,
                  size: 18,
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    error!,
                    style: const TextStyle(
                      color: Color(0xFF9A2E3E),
                      fontSize: 12,
                    ),
                  ),
                ),
              ],
            ),
          ),

        if (!hasRoutes &&
            !loading &&
            error == null)
          SoftCard(
            color: blush,
            child: Row(
              children: [
                const Icon(
                  Icons.route_outlined,
                  color: plum,
                  size: 20,
                ),
                const SizedBox(width: 10),
                const Expanded(
                  child: Text(
                    'Enter a start and destination, or tap the pin icon to use your current location, and real routes will appear here.',
                    style: TextStyle(
                      color: plum,
                      fontSize: 12,
                      height: 1.4,
                    ),
                  ),
                ),
              ],
            ),
          ),

        if (hasRoutes)
          ...routes.map(
            (route) => Padding(
              padding:
                  const EdgeInsets.only(bottom: 8),
              child: RouteOption(
                route: route,
                selected:
                    route.id == selectedId,
                recommended:
                    route.id == routes.first.id,
                onTap: () {
                  if (!mounted) return;

                  setState(() {
                    selectedId = route.id;
                    guiding = false;
                    step = 0;
                  });
                },
              ),
            ),
          ),

        if (hasRoutes) ...[
          SoftCard(
            color: plum,
            child: Column(
              crossAxisAlignment:
                  CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment:
                      MainAxisAlignment.spaceBetween,
                  children: [
                    Column(
                      crossAxisAlignment:
                          CrossAxisAlignment.start,
                      children: [
                        const Text(
                          'SELECTED PATH',
                          style: TextStyle(
                            color: Color(0xFFD9B5D2),
                            fontSize: 9,
                            fontWeight: FontWeight.w800,
                            letterSpacing: 1,
                          ),
                        ),
                        const SizedBox(height: 5),
                        Text(
                          active.name,
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 17,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ],
                    ),

                    Column(
                      crossAxisAlignment:
                          CrossAxisAlignment.end,
                      children: [
                        Text(
                          '${active.safetyScore}%',
                          style: const TextStyle(
                            color: blushStrong,
                            fontSize: 24,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                        const Text(
                          'CONFIDENCE',
                          style: TextStyle(
                            color: Color(0xFFD9B5D2),
                            fontSize: 8,
                            fontWeight: FontWeight.w800,
                            letterSpacing: .7,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),

                const SizedBox(height: 15),

                ClipRRect(
                  borderRadius:
                      BorderRadius.circular(3),
                  child: LinearProgressIndicator(
                    value:
                        active.safetyScore / 100,
                    backgroundColor:
                        const Color(0xFF6C3764),
                    color: active.color,
                    minHeight: 5,
                  ),
                ),

                const SizedBox(height: 10),

                Text(
                  active.havens.isEmpty
                      ? 'No verified safety havens found within reach of this route.'
                      : '${active.havens.length} verified safety haven(s) nearby: ${active.havens.take(3).map((h) => h.name).join(', ')}.',
                  style: const TextStyle(
                    color: Color(0xFFEEDCE9),
                    fontSize: 11,
                    height: 1.5,
                  ),
                ),
              ],
            ),
          ),

          const SizedBox(height: 20),

          SectionHeading(
            eyebrow: 'DIRECTIONS',
            title: guiding
                ? 'Step ${step + 1} of ${active.steps.length}'
                : 'Your route, step by step',
          ),

          SoftCard(
            child: Column(
              children: [
                ...active.steps
                    .asMap()
                    .entries
                    .map((entry) {
                  final index = entry.key;

                  final isActive =
                      guiding && index == step;

                  return Container(
                    padding:
                        const EdgeInsets.symmetric(
                      vertical: 12,
                    ),
                    decoration: BoxDecoration(
                      border: index <
                              active.steps.length - 1
                          ? const Border(
                              bottom: BorderSide(
                                color:
                                    Color(0xFFF5EDF0),
                              ),
                            )
                          : null,
                    ),
                    child: Row(
                      children: [
                        Container(
                          width: 25,
                          height: 25,
                          decoration: BoxDecoration(
                            color: isActive
                                ? blushStrong
                                : const Color(
                                    0xFFF4EBED,
                                  ),
                            borderRadius:
                                BorderRadius.circular(
                              9,
                            ),
                          ),
                          alignment:
                              Alignment.center,
                          child: Text(
                            '${index + 1}',
                            style: TextStyle(
                              color: isActive
                                  ? coral
                                  : muted,
                              fontSize: 10,
                              fontWeight:
                                  FontWeight.w800,
                            ),
                          ),
                        ),

                        const SizedBox(width: 10),

                        Expanded(
                          child: Text(
                            entry.value,
                            style: TextStyle(
                              color: isActive
                                  ? ink
                                  : const Color(
                                      0xFF6F626D,
                                    ),
                              fontSize: 11,
                              height: 1.45,
                              fontWeight: isActive
                                  ? FontWeight.w700
                                  : FontWeight.w400,
                            ),
                          ),
                        ),

                        if (isActive)
                          const Icon(
                            Icons.navigation_outlined,
                            color: coral,
                            size: 15,
                          ),
                      ],
                    ),
                  );
                }),

                const SizedBox(height: 5),

                SizedBox(
                  width: double.infinity,
                  child: FilledButton.icon(
                    onPressed: () {
                      if (!mounted) return;

                      if (!guiding) {
                        setState(() {
                          guiding = true;
                          step = 0;
                        });
                      } else if (step <
                          active.steps.length - 1) {
                        setState(() {
                          step++;
                        });
                      } else {
                        setState(() {
                          guiding = false;
                        });

                        SafetyStatsService.recordTripCompleted(
                          source: sourceController.text.trim().isEmpty ? 'Start' : sourceController.text.trim(),
                          destination: destinationController.text.trim().isEmpty ? 'Destination' : destinationController.text.trim(),
                          safetyScore: active.safetyScore,
                          havenCount: active.havens.length,
                          durationLabel: active.durationLabel,
                        );

                        if (!mounted) return;

                        showAppDialog(
                          context,
                          'You made it',
                          'You have reached your destination. SafeHer kept your real route visible the whole way, and this trip now counts toward your safety insights.',
                        );
                      }
                    },
                    icon: Icon(
                      guiding
                          ? Icons.arrow_forward_rounded
                          : Icons.navigation_outlined,
                      size: 16,
                    ),
                    label: Text(
                      guiding
                          ? (step ==
                                  active.steps.length - 1
                              ? 'Finish route'
                              : 'Next direction')
                          : 'Start in-app guidance',
                    ),
                    style: FilledButton.styleFrom(
                      backgroundColor: coral,
                      padding:
                          const EdgeInsets.symmetric(
                        vertical: 13,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],

        const Padding(
          padding: EdgeInsets.symmetric(
            horizontal: 14,
            vertical: 12,
          ),
          child: Text(
            'Routes are generated live from OpenStreetMap data. The safety score is a transparent heuristic (directness + nearby havens), not a measured crime or lighting signal — always trust your instincts and local emergency services.',
            textAlign: TextAlign.center,
            style: TextStyle(
              color: Color(0xFF9B8D97),
              fontSize: 10,
              height: 1.5,
            ),
          ),
        ),
      ],
    );
  }

  SafeRoute _placeholder() => const SafeRoute(
        id: 'placeholder',
        name: 'No route yet',
        subtitle: '',
        distanceMeters: 0,
        durationSeconds: 0,
        safetyScore: 0,
        havens: [],
        color: muted,
        points: [],
        steps: [],
      );
}

