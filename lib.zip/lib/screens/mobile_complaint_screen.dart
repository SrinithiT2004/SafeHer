import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart' show PlatformException;
import 'package:image_picker/image_picker.dart';
import 'package:share_plus/share_plus.dart';

import '../services/emergency_service.dart';
import '../services/location_service.dart';
import '../services/sms_service.dart';
import '../theme.dart';
import '../widgets/shared_widgets.dart';

/// One photo or video the person attached as evidence.
class _Attachment {
  const _Attachment(this.file, this.isVideo);

  final XFile file;
  final bool isVideo;
}

/// Lets the person file a written complaint without waiting on hold: pick a
/// category, describe what happened, attach photo / video evidence, and send
/// it — with their live location attached — straight to a helpline number's
/// SMS line, sent directly from SafeHer rather than handing off to the
/// Messages app. A "Call instead" button covers the voice-complaint half of
/// the same workflow.
///
/// SMS can only carry text, so the text goes out by SMS first and the media
/// is then handed to the system share sheet (WhatsApp, email, Drive, a
/// trusted contact...) for the person to send wherever the complaint is
/// being filed.
class MobileComplaintScreen extends StatefulWidget {
  const MobileComplaintScreen({super.key});

  @override
  State<MobileComplaintScreen> createState() => _MobileComplaintScreenState();
}

class _MobileComplaintScreenState extends State<MobileComplaintScreen> {
  static const _categories = [
    'Harassment / stalking',
    'Theft or robbery',
    'Assault',
    'Accident',
    'Suspicious activity',
    'Other',
  ];

  static const _maxAttachments = 5;
  static const _maxBytesPerFile = 50 * 1024 * 1024; // 50 MB
  static const _videoExtensions = {'mp4', 'mov', 'm4v', '3gp', 'webm', 'mkv', 'avi'};

  final _picker = ImagePicker();
  final List<_Attachment> _attachments = [];

  String _category = _categories.first;
  bool _includeLocation = true;
  bool _sending = false;
  bool _picking = false;
  final _descriptionController = TextEditingController();
  final _numberController = TextEditingController(text: '100');

  @override
  void dispose() {
    _descriptionController.dispose();
    _numberController.dispose();
    super.dispose();
  }

  void _snack(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
  }

  // ---- media ---------------------------------------------------------

  bool _looksLikeVideo(XFile file) {
    final mime = file.mimeType;
    if (mime != null) return mime.startsWith('video/');
    final path = file.path.toLowerCase();
    final dot = path.lastIndexOf('.');
    return dot != -1 && _videoExtensions.contains(path.substring(dot + 1));
  }

  Future<void> _addFiles(List<XFile> files) async {
    var tooLarge = 0;
    var overLimit = 0;
    for (final file in files) {
      if (_attachments.any((a) => a.file.path == file.path)) continue;
      if (_attachments.length >= _maxAttachments) {
        overLimit++;
        continue;
      }
      if (await file.length() > _maxBytesPerFile) {
        tooLarge++;
        continue;
      }
      _attachments.add(_Attachment(file, _looksLikeVideo(file)));
    }
    if (!mounted) return;
    setState(() {});
    if (overLimit > 0) _snack('You can attach up to $_maxAttachments photos / videos.');
    if (tooLarge > 0) _snack('${tooLarge == 1 ? 'A file was' : '$tooLarge files were'} skipped — each one must be under 50 MB.');
  }

  /// Wraps a picker call so a denied permission or a cancelled/failed pick
  /// gives a clear message instead of an unhandled exception.
  Future<void> _runPicker(Future<void> Function() action) async {
    if (_picking) return;
    setState(() => _picking = true);
    try {
      await action();
    } on PlatformException catch (e) {
      _snack(e.code.contains('denied') ? 'Allow camera / photo access in Settings to attach media.' : "Couldn't attach that file.");
    } catch (_) {
      _snack("Couldn't attach that file.");
    } finally {
      if (mounted) setState(() => _picking = false);
    }
  }

  Future<void> _takePhoto() => _runPicker(() async {
        if (_attachments.length >= _maxAttachments) return _snack('You can attach up to $_maxAttachments photos / videos.');
        final file = await _picker.pickImage(source: ImageSource.camera, imageQuality: 85, maxWidth: 1920);
        if (file != null) await _addFiles([file]);
      });

  Future<void> _recordVideo() => _runPicker(() async {
        if (_attachments.length >= _maxAttachments) return _snack('You can attach up to $_maxAttachments photos / videos.');
        final file = await _picker.pickVideo(source: ImageSource.camera, maxDuration: const Duration(minutes: 1));
        if (file != null) await _addFiles([file]);
      });

  Future<void> _pickFromGallery() => _runPicker(() async {
        final remaining = _maxAttachments - _attachments.length;
        if (remaining <= 0) return _snack('You can attach up to $_maxAttachments photos / videos.');
        List<XFile> files;
        if (remaining == 1) {
          // pickMultipleMedia needs a limit of at least 2.
          final one = await _picker.pickMedia();
          files = one == null ? const [] : [one];
        } else {
          files = await _picker.pickMultipleMedia(limit: remaining);
        }
        if (files.isNotEmpty) await _addFiles(files);
      });

  void _removeAttachment(int index) => setState(() => _attachments.removeAt(index));

  Future<void> _shareEvidence() async {
    if (_attachments.isEmpty) return;
    final details = _descriptionController.text.trim();
    try {
      await SharePlus.instance.share(
        ShareParams(
          files: [for (final a in _attachments) a.file],
          subject: 'SafeHer complaint: $_category',
          text: 'SafeHer complaint – $_category${details.isEmpty ? '' : '\n$details'}',
        ),
      );
    } catch (_) {
      _snack("Couldn't open the share sheet.");
    }
  }

  /// After the text has gone out, offer to send the media. Asked in a dialog
  /// (rather than auto-opening the share sheet) so it still works on iOS,
  /// where the messaging composer has just taken over the screen.
  Future<void> _promptShareEvidence() async {
    final count = _attachments.length;
    final go = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Send your photos & videos'),
        content: Text(
          "Your complaint text has gone out. SMS can't carry media, so choose where to send your $count attachment${count == 1 ? '' : 's'} — "
          'WhatsApp, email, Drive, or a trusted contact.',
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(dialogContext, false), child: const Text('Later')),
          FilledButton(
            onPressed: () => Navigator.pop(dialogContext, true),
            style: FilledButton.styleFrom(backgroundColor: plum),
            child: const Text('Share now'),
          ),
        ],
      ),
    );
    if (go == true && mounted) await _shareEvidence();
  }

  // ---- sending -------------------------------------------------------

  Future<String> _buildMessage() async {
    final buffer = StringBuffer('MOBILE COMPLAINT\nCategory: $_category\nDetails: ${_descriptionController.text.trim()}');
    final photos = _attachments.where((a) => !a.isVideo).length;
    final videos = _attachments.length - photos;
    if (_attachments.isNotEmpty) {
      final parts = [
        if (photos > 0) '$photos photo${photos == 1 ? '' : 's'}',
        if (videos > 0) '$videos video${videos == 1 ? '' : 's'}',
      ];
      buffer.write('\nEvidence: ${parts.join(' + ')} — being sent separately.');
    }
    if (_includeLocation) {
      final position = await LocationService.currentPosition();
      if (position != null) {
        final lat = position.latitude.toStringAsFixed(6);
        final lon = position.longitude.toStringAsFixed(6);
        buffer.write('\nLocation: https://www.openstreetmap.org/?mlat=$lat&mlon=$lon#map=18/$lat/$lon');
      }
    }
    buffer.write('\nSent via SafeHer app.');
    return buffer.toString();
  }

  Future<void> _submit() async {
    if (_descriptionController.text.trim().isEmpty) {
      _snack('Please describe what happened first.');
      return;
    }
    final number = _numberController.text.trim();
    if (number.isEmpty) {
      _snack('Enter a number to send the complaint to.');
      return;
    }

    setState(() => _sending = true);
    SosSendOutcome? outcome;
    try {
      final message = await _buildMessage();
      // Sends straight from SafeHer (same direct-SMS path SOS uses) instead
      // of handing off to the Messages app. Only falls back to opening the
      // composer if direct sending genuinely isn't possible (iOS, or SMS
      // permission declined on Android).
      final result = await SmsService.sendSos(phoneNumbers: [number], message: message);
      outcome = result.outcome;
      if (!mounted) return;
      switch (result.outcome) {
        case SosSendOutcome.sentDirectly:
          _snack('Complaint sent, with your location, from SafeHer.');
          break;
        case SosSendOutcome.openedComposer:
          _snack(Platform.isIOS
              ? "iOS doesn't allow apps to send texts silently, so your messaging app opened prefilled — just tap Send."
              : 'SafeHer opened your messaging app prefilled because SMS permission was not granted — allow it in Settings to send directly next time.');
          break;
        case SosSendOutcome.noContacts:
        case SosSendOutcome.failed:
          _snack("Couldn't send the complaint. You can call instead.");
          break;
      }
    } finally {
      if (mounted) setState(() => _sending = false);
    }

    final textWentOut = outcome == SosSendOutcome.sentDirectly || outcome == SosSendOutcome.openedComposer;
    if (mounted && textWentOut && _attachments.isNotEmpty) {
      await _promptShareEvidence();
    }
  }

  Future<void> _callInstead() async {
    final number = _numberController.text.trim();
    if (number.isEmpty) return;
    final result = await EmergencyService.call(number);
    if (!mounted) return;
    if (result == CallResult.openedDialer) {
      _snack('Dialer opened with the number ready.');
    } else if (result == CallResult.failed) {
      _snack("Couldn't place the call.");
    }
  }

  // ---- UI ------------------------------------------------------------

  Widget _mediaButton({required IconData icon, required String label, required VoidCallback onTap}) {
    return Expanded(
      child: OutlinedButton.icon(
        onPressed: (_picking || _sending) ? null : onTap,
        icon: Icon(icon, size: 17, color: plum),
        label: Text(label, style: const TextStyle(color: plum, fontSize: 12, fontWeight: FontWeight.w700)),
        style: OutlinedButton.styleFrom(
          side: const BorderSide(color: blushStrong),
          padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 10),
        ),
      ),
    );
  }

  Widget _thumbnail(int index) {
    final attachment = _attachments[index];
    return Stack(clipBehavior: Clip.none, children: [
      ClipRRect(
        borderRadius: BorderRadius.circular(12),
        child: SizedBox(
          width: 72,
          height: 72,
          child: attachment.isVideo
              ? Container(
                  color: plum,
                  child: const Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                    Icon(Icons.play_circle_outline_rounded, color: Colors.white, size: 26),
                    SizedBox(height: 2),
                    Text('VIDEO', style: TextStyle(color: blushStrong, fontSize: 8, fontWeight: FontWeight.w800, letterSpacing: .8)),
                  ]),
                )
              : Image.file(
                  File(attachment.file.path),
                  fit: BoxFit.cover,
                  cacheWidth: 220,
                  errorBuilder: (_, __, ___) => Container(color: blush, child: const Icon(Icons.broken_image_outlined, color: muted)),
                ),
        ),
      ),
      Positioned(
        top: -6,
        right: -6,
        child: GestureDetector(
          onTap: () => _removeAttachment(index),
          child: const CircleAvatar(radius: 10, backgroundColor: ink, child: Icon(Icons.close, size: 12, color: Colors.white)),
        ),
      ),
    ]);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: background,
      appBar: AppBar(
        backgroundColor: background,
        elevation: 0,
        iconTheme: const IconThemeData(color: ink),
        title: const Text('Mobile Complaint', style: TextStyle(color: ink, fontWeight: FontWeight.w700)),
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(20, 4, 20, 24),
          children: [
            const Text(
              'File a complaint without waiting on hold — describe what happened, add photos or video as evidence, and send it, with your location, straight from SafeHer to the number below.',
              style: TextStyle(color: muted, fontSize: 12.5, height: 1.4),
            ),
            const SizedBox(height: 16),
            const SectionHeading(eyebrow: 'CATEGORY', title: 'What happened?'),
            SoftCard(
              child: DropdownButtonHideUnderline(
                child: DropdownButton<String>(
                  value: _category,
                  isExpanded: true,
                  items: _categories.map((c) => DropdownMenuItem(value: c, child: Text(c, style: const TextStyle(fontSize: 13, color: ink)))).toList(),
                  onChanged: (value) => setState(() => _category = value ?? _category),
                ),
              ),
            ),
            const SizedBox(height: 14),
            const SectionHeading(eyebrow: 'DETAILS', title: 'Describe the incident'),
            SoftCard(
              child: TextField(
                controller: _descriptionController,
                maxLines: 4,
                decoration: const InputDecoration(border: InputBorder.none, hintText: 'What happened, where, and when...'),
                style: const TextStyle(fontSize: 13, color: ink),
              ),
            ),
            const SizedBox(height: 14),
            SectionHeading(
              eyebrow: 'EVIDENCE',
              title: 'Photos & videos',
              action: Text('${_attachments.length}/$_maxAttachments', style: const TextStyle(color: muted, fontSize: 11, fontWeight: FontWeight.w700)),
            ),
            SoftCard(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(children: [
                  _mediaButton(icon: Icons.photo_camera_outlined, label: 'Photo', onTap: _takePhoto),
                  const SizedBox(width: 8),
                  _mediaButton(icon: Icons.videocam_outlined, label: 'Video', onTap: _recordVideo),
                  const SizedBox(width: 8),
                  _mediaButton(icon: Icons.photo_library_outlined, label: 'Gallery', onTap: _pickFromGallery),
                ]),
                if (_attachments.isNotEmpty) ...[
                  const SizedBox(height: 12),
                  SizedBox(
                    height: 84,
                    child: ListView.separated(
                      scrollDirection: Axis.horizontal,
                      padding: const EdgeInsets.only(top: 8, right: 8),
                      itemCount: _attachments.length,
                      separatorBuilder: (_, __) => const SizedBox(width: 10),
                      itemBuilder: (_, index) => _thumbnail(index),
                    ),
                  ),
                ],
                const SizedBox(height: 10),
                const Text(
                  "SMS can't carry media, so your text is sent first and SafeHer then opens the share sheet for the photos / videos (WhatsApp, email, Drive…). Up to 5 files, 50 MB each, videos up to 1 min from the camera.",
                  style: TextStyle(color: muted, fontSize: 10.5, height: 1.4),
                ),
              ]),
            ),
            const SizedBox(height: 14),
            SoftCard(
              child: SwitchListTile(
                contentPadding: EdgeInsets.zero,
                value: _includeLocation,
                onChanged: (value) => setState(() => _includeLocation = value),
                activeThumbColor: coral,
                title: const Text('Attach my live location', style: TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: ink)),
                subtitle: const Text('A map link is added to the message', style: TextStyle(fontSize: 11, color: muted)),
              ),
            ),
            const SizedBox(height: 14),
            const SectionHeading(eyebrow: 'SEND TO', title: 'Helpline number'),
            SoftCard(
              child: TextField(
                controller: _numberController,
                keyboardType: TextInputType.phone,
                decoration: const InputDecoration(border: InputBorder.none, prefixIcon: Icon(Icons.dialpad, color: muted, size: 18)),
                style: const TextStyle(fontSize: 13, color: ink),
              ),
            ),
            const SizedBox(height: 20),
            SizedBox(
              height: 52,
              child: FilledButton.icon(
                onPressed: _sending ? null : _submit,
                icon: _sending
                    ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                    : const Icon(Icons.send_rounded),
                label: Text(_attachments.isEmpty ? 'Send complaint from SafeHer' : 'Send complaint + share evidence'),
                style: FilledButton.styleFrom(backgroundColor: plum, foregroundColor: Colors.white, textStyle: const TextStyle(fontWeight: FontWeight.w800)),
              ),
            ),
            if (_attachments.isNotEmpty) ...[
              const SizedBox(height: 10),
              SizedBox(
                height: 48,
                child: OutlinedButton.icon(
                  onPressed: _sending ? null : _shareEvidence,
                  icon: const Icon(Icons.ios_share_rounded, color: plum),
                  label: Text(
                    'Share ${_attachments.length} attachment${_attachments.length == 1 ? '' : 's'} only',
                    style: const TextStyle(color: plum, fontWeight: FontWeight.w800),
                  ),
                  style: OutlinedButton.styleFrom(side: const BorderSide(color: blushStrong)),
                ),
              ),
            ],
            const SizedBox(height: 10),
            SizedBox(
              height: 48,
              child: OutlinedButton.icon(
                onPressed: _callInstead,
                icon: const Icon(Icons.call_outlined, color: green),
                label: const Text('Call instead', style: TextStyle(color: green, fontWeight: FontWeight.w800)),
                style: OutlinedButton.styleFrom(side: const BorderSide(color: Color(0xFFBFE0D2))),
              ),
            ),
          ],
        ),
      ),
    );
  }
}