import 'dart:io';

import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../theme.dart';

/// First-launch registration. Collects the essentials SafeHer's other
/// features already depend on — the person's name (shown across the app)
/// and one trusted emergency contact (used by SOS and the Home tab's
/// "trusted contacts" card) — so SOS has somewhere to send an alert from
/// the very first run, instead of starting empty.
///
/// Saves into the same SharedPreferences keys ProfileTab already reads
/// ('name', 'contacts'), so anything entered here shows up there too, and
/// can be edited later from the Profile tab.
class RegistrationScreen extends StatefulWidget {
  const RegistrationScreen({super.key, required this.onComplete});

  /// Called once registration is saved, so the caller can swap to AppShell.
  final VoidCallback onComplete;

  @override
  State<RegistrationScreen> createState() => _RegistrationScreenState();
}

class _RegistrationScreenState extends State<RegistrationScreen> {
  final _formKey = GlobalKey<FormState>();

  final _nameController = TextEditingController();
  final _emailController = TextEditingController();
  final _phoneController = TextEditingController();
  final _emergencyNameController = TextEditingController();
  final _emergencyPhoneController = TextEditingController();

  bool _saving = false;

  @override
  void dispose() {
    _nameController.dispose();
    _emailController.dispose();
    _phoneController.dispose();
    _emergencyNameController.dispose();
    _emergencyPhoneController.dispose();
    super.dispose();
  }

  String? _requiredName(String? value) {
    if (value == null || value.trim().isEmpty) return 'Enter your name';
    return null;
  }

  String? _requiredPhone(String? value) {
    final digits = (value ?? '').replaceAll(RegExp(r'[^0-9+]'), '');
    if (digits.length < 7) return 'Enter a valid phone number';
    return null;
  }

  String? _optionalEmail(String? value) {
    final trimmed = (value ?? '').trim();
    if (trimmed.isEmpty) return null;
    final valid = RegExp(r'^[^@\s]+@[^@\s]+\.[^@\s]+$').hasMatch(trimmed);
    return valid ? null : 'Enter a valid email';
  }

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() => _saving = true);
    try {
      final prefs = await SharedPreferences.getInstance();

      final name = _nameController.text.trim();
      final email = _emailController.text.trim();
      final phone = _phoneController.text.trim().replaceAll(RegExp(r'[^0-9+]'), '');
      final emergencyName = _emergencyNameController.text.trim();
      final emergencyPhone = _emergencyPhoneController.text.trim().replaceAll(RegExp(r'[^0-9+]'), '');

      await prefs.setString('name', name);
      await prefs.setString('email', email);
      await prefs.setString('phone', phone);

      final existingContacts = prefs.getStringList('contacts') ?? <String>[];
      final entry = '$emergencyName|$emergencyPhone';
      if (!existingContacts.contains(entry)) {
        await prefs.setStringList('contacts', [entry, ...existingContacts]);
      }

      await prefs.setBool('registered', true);

      // Ask for call + SMS permission now, up front, instead of the moment
      // of a real emergency. Granted here, SOS, emergency dial, and mobile
      // complaint all go straight out from SafeHer later with no dialer or
      // messaging-app detour and no permission prompt interrupting a crisis.
      if (Platform.isAndroid) {
        await [Permission.phone, Permission.sms].request();
      }

      if (!mounted) return;
      widget.onComplete();
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: background,
      body: SafeArea(
        child: Form(
          key: _formKey,
          child: ListView(
            padding: const EdgeInsets.fromLTRB(24, 40, 24, 32),
            children: [
              Container(
                width: 56,
                height: 56,
                decoration: BoxDecoration(color: blushStrong, borderRadius: BorderRadius.circular(18)),
                child: const Icon(Icons.shield_rounded, color: plum, size: 28),
              ),
              const SizedBox(height: 18),
              const Text('Welcome to SafeHer', style: TextStyle(color: ink, fontSize: 26, fontWeight: FontWeight.w800)),
              const SizedBox(height: 6),
              const Text(
                "Let's set up your safety profile — this only takes a minute, and it's what SOS uses to reach someone for you.",
                style: TextStyle(color: muted, fontSize: 13, height: 1.45),
              ),
              const SizedBox(height: 28),

              const _FieldLabel('YOUR DETAILS'),
              _RegField(
                controller: _nameController,
                label: 'Full name',
                icon: Icons.person_outline,
                validator: _requiredName,
                textCapitalization: TextCapitalization.words,
              ),
              const SizedBox(height: 12),
              _RegField(
                controller: _phoneController,
                label: 'Your phone number',
                icon: Icons.phone_outlined,
                validator: _requiredPhone,
                keyboardType: TextInputType.phone,
              ),
              const SizedBox(height: 12),
              _RegField(
                controller: _emailController,
                label: 'Email (optional)',
                icon: Icons.mail_outline,
                validator: _optionalEmail,
                keyboardType: TextInputType.emailAddress,
              ),

              const SizedBox(height: 24),
              const _FieldLabel('EMERGENCY CONTACT'),
              const Text(
                'The first person SafeHer alerts when you activate SOS. You can add more from the Profile tab later.',
                style: TextStyle(color: muted, fontSize: 11.5, height: 1.4),
              ),
              const SizedBox(height: 12),
              _RegField(
                controller: _emergencyNameController,
                label: 'Contact name',
                icon: Icons.favorite_border,
                validator: _requiredName,
                textCapitalization: TextCapitalization.words,
              ),
              const SizedBox(height: 12),
              _RegField(
                controller: _emergencyPhoneController,
                label: 'Contact phone number',
                icon: Icons.call_outlined,
                validator: _requiredPhone,
                keyboardType: TextInputType.phone,
              ),

              const SizedBox(height: 28),
              SizedBox(
                height: 54,
                child: FilledButton.icon(
                  onPressed: _saving ? null : _submit,
                  icon: _saving
                      ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                      : const Icon(Icons.arrow_forward_rounded),
                  label: const Text('Get started'),
                  style: FilledButton.styleFrom(backgroundColor: plum, foregroundColor: Colors.white, textStyle: const TextStyle(fontWeight: FontWeight.w800)),
                ),
              ),
              const SizedBox(height: 12),
              const Text(
                'Your details are stored only on this device.',
                textAlign: TextAlign.center,
                style: TextStyle(color: Color(0xFF9B8D97), fontSize: 10.5),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _FieldLabel extends StatelessWidget {
  const _FieldLabel(this.text);

  final String text;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Text(text, style: const TextStyle(color: plum, fontSize: 10.5, fontWeight: FontWeight.w800, letterSpacing: 1)),
    );
  }
}

class _RegField extends StatelessWidget {
  const _RegField({
    required this.controller,
    required this.label,
    required this.icon,
    this.validator,
    this.keyboardType,
    this.textCapitalization = TextCapitalization.none,
  });

  final TextEditingController controller;
  final String label;
  final IconData icon;
  final String? Function(String?)? validator;
  final TextInputType? keyboardType;
  final TextCapitalization textCapitalization;

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16), border: Border.all(color: border)),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 2),
      child: TextFormField(
        controller: controller,
        validator: validator,
        keyboardType: keyboardType,
        textCapitalization: textCapitalization,
        style: const TextStyle(color: ink, fontSize: 14, fontWeight: FontWeight.w600),
        decoration: InputDecoration(
          border: InputBorder.none,
          labelText: label,
          labelStyle: const TextStyle(color: muted, fontSize: 12.5),
          prefixIcon: Icon(icon, color: coral, size: 19),
          errorMaxLines: 2,
        ),
      ),
    );
  }
}
