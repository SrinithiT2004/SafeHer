import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../services/emergency_service.dart';
import '../theme.dart';
import '../widgets/shared_widgets.dart';
import '../services/safety_stats_service.dart';

class ProfileTab extends StatefulWidget {
  const ProfileTab({super.key});

  @override
  State<ProfileTab> createState() => _ProfileTabState();
}

class _ProfileTabState extends State<ProfileTab> {
  bool sharing = true;
  String name = 'Lina Menon';
  List<String> contacts = <String>[];

  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _phoneController = TextEditingController();

  @override
  void initState() {
    super.initState();
    loadProfile();
  }

  @override
  void dispose() {
    _nameController.dispose();
    _phoneController.dispose();
    super.dispose();
  }

  Future<void> loadProfile() async {
    final prefs = await SharedPreferences.getInstance();
    final saved = prefs.getStringList('contacts') ?? <String>[];
    final migrated = saved.map((item) {
      if (item.contains('|')) return item;
      final nameOnly = item.split(' · ').first.trim();
      return '$nameOnly|';
    }).toList();

    if (!mounted) return;
    setState(() {
      sharing = prefs.getBool('sharing') ?? true;
      name = prefs.getString('name') ?? 'Lina Menon';
      contacts = migrated;
    });
  }

  Future<void> saveProfile() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('sharing', sharing);
    await prefs.setString('name', name);
    await prefs.setStringList('contacts', contacts);
    SafetyStatsService.revision.value++;
  }

  String contactName(String value) => value.split('|').first.trim();

  String contactPhone(String value) {
    final parts = value.split('|');
    return parts.length > 1 ? parts[1].trim() : '';
  }

  /// Compares numbers by their last 10 digits, so "+91 98765 43210",
  /// "9876543210" and "098765-43210" all count as the same contact.
  String _normalizePhone(String value) {
    final digits = value.replaceAll(RegExp(r'[^0-9]'), '');
    return digits.length > 10 ? digits.substring(digits.length - 10) : digits;
  }

  /// Returns the name of an existing contact that already uses [phone], or
  /// null if the number is new. [ignoreIndex] skips the contact being edited.
  String? _existingContactWithPhone(String phone, {int? ignoreIndex}) {
    final target = _normalizePhone(phone);
    if (target.isEmpty) return null;
    for (var i = 0; i < contacts.length; i++) {
      if (i == ignoreIndex) continue;
      if (_normalizePhone(contactPhone(contacts[i])) == target) {
        return contactName(contacts[i]);
      }
    }
    return null;
  }

  Future<void> editName() async {
    _nameController.text = name;
    String? error;
    await showDialog<void>(
      context: context,
      builder: (dialogContext) => StatefulBuilder(
        builder: (dialogContext, setDialogState) => AlertDialog(
          title: const Text('Edit profile'),
          content: TextField(
            controller: _nameController,
            autofocus: true,
            textCapitalization: TextCapitalization.words,
            decoration: InputDecoration(
              labelText: 'Your name',
              prefixIcon: const Icon(Icons.person_outline),
              errorText: error,
            ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('Cancel')),
            FilledButton(
              onPressed: () {
                final value = _nameController.text.trim();
                if (value.isEmpty) {
                  setDialogState(() => error = 'Enter a name before saving');
                  return;
                }
                setState(() => name = value);
                saveProfile();
                Navigator.pop(dialogContext);
                if (mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Profile saved'), duration: Duration(seconds: 2)));
                }
              },
              child: const Text('Save'),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> editContact(int index) async {
    final oldName = contactName(contacts[index]);
    final oldPhone = contactPhone(contacts[index]);
    _nameController.text = oldName;
    _phoneController.text = oldPhone;
    String? error;
    String? nameError;

    await showDialog<void>(
      context: context,
      builder: (dialogContext) => StatefulBuilder(
        builder: (dialogContext, setDialogState) => AlertDialog(
          title: const Text('Edit safety contact'),
          content: Column(mainAxisSize: MainAxisSize.min, children: [
            TextField(
              controller: _nameController,
              textCapitalization: TextCapitalization.words,
              decoration: InputDecoration(labelText: 'Contact name', prefixIcon: const Icon(Icons.person_outline), errorText: nameError),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: _phoneController,
              keyboardType: TextInputType.phone,
              decoration: InputDecoration(labelText: 'Phone number (with country code)', prefixIcon: const Icon(Icons.phone_outlined), errorText: error),
            ),
          ]),
          actions: [
            TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('Cancel')),
            FilledButton(
              onPressed: () {
                final newName = _nameController.text.trim();
                final newPhone = _phoneController.text.trim();
                if (newName.isEmpty) {
                  setDialogState(() => nameError = 'Enter a name');
                  return;
                }
                final digits = newPhone.replaceAll(RegExp(r'[^0-9]'), '');
                if (digits.length != 10) {
                  setDialogState(() => error = 'Enter correct phone number');
                  return;
                }
                final existing = _existingContactWithPhone(digits, ignoreIndex: index);
                if (existing != null) {
                  setDialogState(() => error = 'This number already exists (saved as $existing)');
                  return;
                }
                setState(() => contacts[index] = '$newName|$digits');
                saveProfile();
                Navigator.pop(dialogContext);
                if (mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Contact saved'), duration: Duration(seconds: 2)));
                }
              },
              child: const Text('Save'),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> addContact() async {
    _nameController.clear();
    _phoneController.clear();
    String? error;
    String? nameError;

    await showDialog<void>(
      context: context,
      builder: (dialogContext) => StatefulBuilder(
        builder: (dialogContext, setDialogState) => AlertDialog(
          title: const Text('Add a safety contact'),
          content: Column(mainAxisSize: MainAxisSize.min, children: [
            TextField(
              controller: _nameController,
              autofocus: true,
              textCapitalization: TextCapitalization.words,
              decoration: InputDecoration(labelText: 'Contact name', prefixIcon: const Icon(Icons.person_outline), errorText: nameError),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: _phoneController,
              keyboardType: TextInputType.phone,
              decoration: InputDecoration(labelText: 'Phone number (with country code)', prefixIcon: const Icon(Icons.phone_outlined), errorText: error),
            ),
          ]),
          actions: [
            TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('Cancel')),
            FilledButton(
              onPressed: () {
                final contactNameValue = _nameController.text.trim();
                final phoneValue = _phoneController.text.trim();
                if (contactNameValue.isEmpty) {
                  setDialogState(() => nameError = 'Enter a name');
                  return;
                }
                final digits = phoneValue.replaceAll(RegExp(r'[^0-9]'), '');
                if (digits.length != 10) {
                  setDialogState(() => error = 'Enter correct phone number');
                  return;
                }
                final existing = _existingContactWithPhone(digits);
                if (existing != null) {
                  setDialogState(() => error = 'This number already exists (saved as $existing)');
                  return;
                }
                setState(() => contacts.add('$contactNameValue|$digits'));
                saveProfile();
                Navigator.pop(dialogContext);
                if (mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Contact added'), duration: Duration(seconds: 2)));
                }
              },
              child: const Text('Add'),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> deleteContact(int index) async {
    setState(() => contacts.removeAt(index));
    await saveProfile();
  }

  Future<void> _openSmsPermissionSettings() async {
    final status = await Permission.sms.status;
    if (status.isPermanentlyDenied) {
      await openAppSettings();
    } else {
      await Permission.sms.request();
    }
    if (!mounted) return;
    showAppDialog(context, 'SMS permission', 'This lets SOS send your live location directly, without opening the messaging app.');
  }

  @override
  Widget build(BuildContext context) {
    final initials = name.trim().split(RegExp(r'\s+')).where((e) => e.isNotEmpty).take(2).map((e) => e[0].toUpperCase()).join();

    return AppScroll(children: [
      const Header(eyebrow: 'YOUR ACCOUNT', title: 'Safety circle', icon: Icons.people_outline),
      const Text('Update your profile and trusted contacts anytime. These details are saved on this device.', style: TextStyle(color: muted, fontSize: 13, height: 1.45)),
      SoftCard(
        child: Row(children: [
          CircleAvatar(radius: 26, backgroundColor: blushStrong, child: Text(initials.isEmpty ? 'SH' : initials, style: const TextStyle(color: plum, fontWeight: FontWeight.w800))),
          const SizedBox(width: 12),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(name, style: const TextStyle(color: ink, fontSize: 16, fontWeight: FontWeight.w800)),
              const SizedBox(height: 4),
              const Text('SafeHer member · profile stored locally', style: TextStyle(color: muted, fontSize: 10)),
            ]),
          ),
          IconButton(onPressed: editName, tooltip: 'Edit profile', icon: const Icon(Icons.edit_outlined, color: coral, size: 19)),
        ]),
      ),
      const SizedBox(height: 4),
      SectionHeading(
        eyebrow: 'TRUSTED CONTACTS',
        title: '${contacts.length} people ready',
        action: TextButton(onPressed: addContact, child: const Text('+ Add', style: TextStyle(color: coral, fontWeight: FontWeight.w800))),
      ),
      SoftCard(
        child: contacts.isEmpty
            ? const Padding(
                padding: EdgeInsets.symmetric(vertical: 14),
                child: Row(children: [
                  Icon(Icons.person_add_alt_1_outlined, color: muted, size: 22),
                  SizedBox(width: 10),
                  Expanded(child: Text('Add a trusted person with their phone number so SOS can alert them automatically.', style: TextStyle(color: muted, fontSize: 11, height: 1.4))),
                ]),
              )
            : Column(
                children: contacts.asMap().entries.map((entry) {
                  final index = entry.key;
                  final value = entry.value;
                  final phone = contactPhone(value);
                  return Container(
                    padding: const EdgeInsets.symmetric(vertical: 11),
                    decoration: BoxDecoration(border: index < contacts.length - 1 ? const Border(bottom: BorderSide(color: Color(0xFFF5EDF0))) : null),
                    child: Row(children: [
                      CircleAvatar(radius: 18, backgroundColor: const Color(0xFFF4EBED), child: Text(contactName(value).isEmpty ? '?' : contactName(value)[0].toUpperCase(), style: const TextStyle(color: coral, fontWeight: FontWeight.w800))),
                      const SizedBox(width: 11),
                      Expanded(
                        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Text(contactName(value), style: const TextStyle(color: Color(0xFF4B3C49), fontSize: 12, fontWeight: FontWeight.w800)),
                          const SizedBox(height: 3),
                          Text(phone.isEmpty ? 'Phone number not added' : phone, style: const TextStyle(color: muted, fontSize: 10)),
                        ]),
                      ),
                      if (phone.isNotEmpty)
                        IconButton(onPressed: () => EmergencyService.dial(phone), tooltip: 'Call', icon: const Icon(Icons.call_outlined, color: green, size: 17)),
                      IconButton(onPressed: () => editContact(index), icon: const Icon(Icons.edit_outlined, color: coral, size: 17)),
                      IconButton(onPressed: () => deleteContact(index), icon: const Icon(Icons.delete_outline, color: muted, size: 17)),
                    ]),
                  );
                }).toList(),
              ),
      ),
      const SizedBox(height: 4),
      const SectionHeading(eyebrow: 'PROTECTION SETTINGS', title: 'Stay supported'),
      SoftCard(
        child: Column(children: [
          SettingRow(
            icon: Icons.share_outlined,
            color: coral,
            title: 'Share live route',
            subtitle: 'Allow live location features during an active trip',
            trailing: Switch(
              value: sharing,
              onChanged: (value) {
                setState(() => sharing = value);
                saveProfile();
              },
              activeThumbColor: coral,
            ),
          ),
          const Divider(color: Color(0xFFF5EDF0)),
          SettingRow(
            icon: Icons.sms_outlined,
            color: plum,
            title: 'Silent SOS SMS',
            subtitle: 'Android permission that lets SOS text contacts with no extra tap',
            trailing: TextButton(onPressed: _openSmsPermissionSettings, child: const Text('Manage', style: TextStyle(color: plum, fontWeight: FontWeight.w800))),
          ),
          const Divider(color: Color(0xFFF5EDF0)),
          const SettingRow(icon: Icons.notifications_none_rounded, color: gold, title: 'Arrival check-in', subtitle: 'Ask if you got there safely', trailing: OnPill()),
        ]),
      ),
      OutlinedButton.icon(
        onPressed: () => showAppDialog(context, 'Safety check', 'Your test alert is ready. SOS itself will use your current GPS position and safety contacts.'),
        icon: const Icon(Icons.radio_outlined, color: plum, size: 16),
        label: const Text('Test my safety check', style: TextStyle(color: plum, fontWeight: FontWeight.w800)),
        style: OutlinedButton.styleFrom(side: const BorderSide(color: Color(0xFFE3D2D9)), padding: const EdgeInsets.symmetric(vertical: 13)),
      ),
      const Padding(
        padding: EdgeInsets.symmetric(horizontal: 14),
        child: Text('Your profile and trusted contacts are stored locally on this device.', textAlign: TextAlign.center, style: TextStyle(color: Color(0xFF9B8D97), fontSize: 10, height: 1.5)),
      ),
    ]);
  }
}