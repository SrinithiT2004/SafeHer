import 'dart:math';

import 'package:flutter/material.dart';
import 'package:latlong2/latlong.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../models.dart';
import '../services/chatbot_service.dart';
import '../services/emergency_service.dart';
import '../services/location_service.dart';
import '../services/routing_service.dart';
import '../services/sms_service.dart';
import '../services/sos_controller.dart';
import '../theme.dart';
import '../widgets/route_map.dart';
import '../widgets/shared_widgets.dart';
import 'mobile_complaint_screen.dart';
import 'safe_havens_screen.dart';

class ChatbotTab extends StatefulWidget {
  const ChatbotTab({super.key});

  @override
  State<ChatbotTab> createState() => _ChatbotTabState();
}

/// What the bot is waiting on the person's *next* message to answer, so a
/// bare reply like "Koramangala" after "where would you like to go?" is
/// understood as the answer, not a fresh unrecognised message.
enum _Pending { none, routeDestination }

class _ChatbotTabState extends State<ChatbotTab> {
  final _controller = TextEditingController();
  final _scrollController = ScrollController();
  final _random = Random();

  late final List<ChatMessage> _messages = [
    ChatMessage(
      text: "Hi, I'm the SafeHer assistant. I don't just point you around the app — I actually send SOS alerts, look up routes and havens, dial emergency numbers, and save contacts, right from this chat.",
      fromUser: false,
      actions: _quickActions(),
    ),
  ];

  bool _busy = false;
  _Pending _pending = _Pending.none;

  @override
  void dispose() {
    _controller.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  List<ChatAction> _quickActions() => [
        ChatAction(label: 'Send SOS', icon: Icons.sos_rounded, onTap: () => _runText('send sos')),
        ChatAction(label: 'Safe havens', icon: Icons.shield_outlined, onTap: () => _runText('safe havens near me')),
        ChatAction(label: 'Call police', icon: Icons.call_outlined, onTap: () => _runText('call police')),
        ChatAction(label: 'File complaint', icon: Icons.edit_document, onTap: () => _runText('file a complaint')),
      ];

  void _runText(String text) {
    _controller.text = text;
    _send();
  }

  void _addBotMessage(ChatMessage message) {
    if (!mounted) return;
    setState(() => _messages.add(message));
    _scrollToEnd();
  }

  void _scrollToEnd() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!_scrollController.hasClients) return;
      _scrollController.animateTo(_scrollController.position.maxScrollExtent, duration: const Duration(milliseconds: 250), curve: Curves.easeOut);
    });
  }

  String _pick(List<String> options) => options[_random.nextInt(options.length)];

  Future<void> _send() async {
    final text = _controller.text.trim();
    if (text.isEmpty || _busy) return;

    setState(() {
      _messages.add(ChatMessage(text: text, fromUser: true));
      _busy = true;
    });
    _controller.clear();
    _scrollToEnd();

    // If the bot just asked a follow-up question, treat this reply as the
    // answer instead of re-parsing it as a brand-new, possibly-unrecognised
    // message — that's what makes the conversation feel continuous.
    if (_pending == _Pending.routeDestination) {
      _pending = _Pending.none;
      await _handleRoute(text);
      if (mounted) setState(() => _busy = false);
      return;
    }

    final parsed = ChatbotService.parse(text);

    try {
      switch (parsed.intent) {
        case ChatIntent.greeting:
          _addBotMessage(ChatMessage(
            text: _pick([
              "Hi! I'm ready — try \"send sos\", \"route to <place>\", or \"safe havens near me\".",
              "Hello! Tell me what's going on and I'll act on it — SOS, a safe route, nearby havens, or a call.",
              "Hey there. I can send an SOS, find a route, look up havens, dial emergency numbers, or file a complaint.",
            ]),
            fromUser: false,
          ));
          break;

        case ChatIntent.thanks:
          _addBotMessage(ChatMessage(
            text: _pick([
              "You're welcome. Stay safe — I'm here if you need anything.",
              'Anytime. Shout if you need me again.',
              "Glad to help. I'm right here if anything changes.",
            ]),
            fromUser: false,
          ));
          break;

        case ChatIntent.sos:
          await _handleSos();
          break;

        case ChatIntent.stopSos:
          await _handleStopSos();
          break;

        case ChatIntent.route:
          await _handleRoute(parsed.destination);
          break;

        case ChatIntent.havens:
          await _handleHavens();
          break;

        case ChatIntent.callEmergency:
          await _handleCallEmergency(parsed.emergencyNumber ?? '112', parsed.emergencyLabel ?? 'Emergency');
          break;

        case ChatIntent.complaint:
          _handleComplaint();
          break;

        case ChatIntent.addContact:
          if (parsed.contactName != null && parsed.contactPhone != null) {
            await _handleAddContact(parsed.contactName!, parsed.contactPhone!);
          } else {
            _addBotMessage( ChatMessage(
              text: 'Give me a name and phone number together, e.g. "add contact Mom 9876543210".',
              fromUser: false,
            ));
          }
          break;

        case ChatIntent.listContacts:
          await _handleListContacts();
          break;

        case ChatIntent.capabilities:
          _addBotMessage(ChatMessage(
            text: "Here's what I can actually do for you:\n"
                '🚨 "send sos" — text your live location to trusted contacts, right now\n'
                '🗺️ "route to <place>" — a real walking route with a safety score\n'
                '🛡️ "safe havens near me" — nearby police, hospitals, pharmacies, pinned on a map\n'
                '📞 "call police" / "dial 112" — opens your dialer\n'
                '📝 "file a complaint" — a complaint form, sent by SMS with your location\n'
                '👤 "add contact Mom 9876543210" — saves a trusted contact for SOS',
            fromUser: false,
          ));
          break;

        case ChatIntent.unknown:
          _addBotMessage(ChatMessage(
            text: "I didn't quite catch an action there. I can send an SOS, find a safe route, show nearby havens, dial an emergency number, file a complaint, or save a contact.",
            fromUser: false,
            actions: _quickActions(),
          ));
          break;
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  // ------------------------------------------------------------
  // SOS — actually sends the live location, doesn't explain the button.
  // ------------------------------------------------------------

  Future<void> _handleSos() async {
    final result = await SosController.instance.activate();

    if (result.isOk) {
      final sendResult = result.sendResult!;
      final contacts = await SosController.instance.loadContacts();
      final sentNames = contacts.where((c) => sendResult.sent.contains(c.$2)).map((c) => c.$1).toList();

      switch (sendResult.outcome) {
        case SosSendOutcome.sentDirectly:
          _addBotMessage(ChatMessage(
            text: sentNames.isEmpty
                ? '🚨 Live location sent to ${sendResult.sent.length} contact(s), automatically — no extra tap needed. I\'ll keep sending updates while SOS stays active. Say "stop sos" to stop.'
                : '🚨 Live location sent to ${sentNames.join(', ')} — automatically, no extra tap needed. I\'ll keep sending updates while SOS stays active. Say "stop sos" to stop.',
            fromUser: false,
          ));
          break;
        case SosSendOutcome.openedComposer:
          _addBotMessage( ChatMessage(
            text: 'Your live location is now tracking, and your messaging app opened prefilled with it — just tap Send there. I\'ll keep tracking your position until you say "stop sos".',
            fromUser: false,
          ));
          break;
        case SosSendOutcome.noContacts:
          _addBotMessage( ChatMessage(
            text: 'Your live location is being tracked now, but you don\'t have any trusted contacts with a phone number yet, so nothing was sent. '
                'Tell me one, e.g. "add contact Mom 9876543210", and I\'ll notify them next time.',
            fromUser: false,
          ));
          break;
        case SosSendOutcome.failed:
          _addBotMessage(ChatMessage(
            text: 'Your live location is tracking on this device, but the alert couldn\'t be sent. Please call your contacts directly if you can.',
            fromUser: false,
            actions: [ChatAction(label: 'Call 112 now', icon: Icons.call_outlined, onTap: () => EmergencyService.dial('112'))],
          ));
          break;
      }
      return;
    }

    _addBotMessage(ChatMessage(
      text: result.failureMessage ?? "SOS couldn't start. Please try again.",
      fromUser: false,
    ));
  }

  Future<void> _handleStopSos() async {
    if (!SosController.instance.active) {
      _addBotMessage( ChatMessage(text: "SOS isn't active right now.", fromUser: false));
      return;
    }
    await SosController.instance.stop();
    _addBotMessage( ChatMessage(text: '✅ SOS stopped. Live location tracking has ended.', fromUser: false));
  }

  // ------------------------------------------------------------
  // ROUTE — fetches a real route right now, previews it inline.
  // ------------------------------------------------------------

  Future<void> _handleRoute(String? destination) async {
    if (destination == null || destination.trim().isEmpty) {
      _pending = _Pending.routeDestination;
      _addBotMessage(ChatMessage(
        text: 'Where would you like to go? Just name the place — e.g. "Koramangala" or "MG Road metro".',
        fromUser: false,
      ));
      return;
    }

    final position = await LocationService.currentPosition();
    if (position == null) {
      final result = await LocationService.ensurePermission();
      final message = LocationService.messageFor(result);
      _addBotMessage(ChatMessage(
        text: message.isEmpty ? "I couldn't get your current location. Make sure GPS is on and try again." : message,
        fromUser: false,
      ));
      return;
    }

    final from = LatLng(position.latitude, position.longitude);

    try {
      final to = await RoutingService.geocode(destination);
      final routes = await RoutingService.fetchRoutes(from: from, to: to, fromLabel: 'My location', toLabel: destination);

      if (routes.isEmpty) {
        _addBotMessage(ChatMessage(text: "I couldn't find a walkable route to \"$destination\".", fromUser: false));
        return;
      }

      final best = routes.first;
      _addBotMessage(ChatMessage(
        text: 'Best route to $destination: ${best.distanceLabel}, about ${best.durationLabel}, safety score ${best.safetyScore}%. '
            '${best.havens.isEmpty ? 'No verified havens nearby.' : '${best.havens.length} safety haven(s) nearby.'}',
        fromUser: false,
        route: best,
        actions: [
          ChatAction(
            label: 'View full route & directions',
            icon: Icons.map_outlined,
            onTap: () {
              if (!mounted) return;
              Navigator.push(context, MaterialPageRoute(builder: (_) => _RoutePreviewScreen(route: best, destinationLabel: destination)));
            },
          ),
        ],
      ));
    } on RoutingException catch (e) {
      _addBotMessage(ChatMessage(text: e.message, fromUser: false));
    } catch (_) {
      _addBotMessage( ChatMessage(text: "Couldn't reach the routing service. Check your connection and try again.", fromUser: false));
    }
  }

  // ------------------------------------------------------------
  // HAVENS — fetches real nearby havens right now; radius expands
  // automatically until enough are found, instead of a fixed distance.
  // ------------------------------------------------------------

  Future<void> _handleHavens() async {
    final position = await LocationService.currentPosition();
    if (position == null) {
      final result = await LocationService.ensurePermission();
      final message = LocationService.messageFor(result);
      _addBotMessage(ChatMessage(
        text: message.isEmpty ? "I couldn't get your current location. Make sure GPS is on and try again." : message,
        fromUser: false,
      ));
      return;
    }

    final center = LatLng(position.latitude, position.longitude);

    try {
      final result = await RoutingService.fetchNearbyHavensAdaptive(center);
      final havens = result.havens;
      const distance = Distance();
      havens.sort((a, b) => distance(center, a.point).compareTo(distance(center, b.point)));

      if (havens.isEmpty) {
        _addBotMessage(ChatMessage(
          text: 'No police stations, hospitals, or pharmacies were found even out to ${result.radiusLabel} of you right now.',
          fromUser: false,
        ));
        return;
      }

      final top = havens.take(4);
      final list = top.map((h) {
        final meters = distance(center, h.point);
        final label = meters >= 1000 ? '${(meters / 1000).toStringAsFixed(1)} km' : '${meters.round()} m';
        return '${h.name} ($label)';
      }).join(', ');

      _addBotMessage(ChatMessage(
        text: 'Nearest safety havens (searched out to ${result.radiusLabel}): $list.',
        fromUser: false,
        havens: havens,
        mapCenter: center,
        actions: [
          ChatAction(
            label: 'Open full map',
            icon: Icons.map_outlined,
            onTap: () {
              if (!mounted) return;
              Navigator.push(context, MaterialPageRoute(builder: (_) => SafeHavensScreen(center: center)));
            },
          ),
        ],
      ));
    } catch (_) {
      _addBotMessage( ChatMessage(text: "Couldn't reach the safety-havens service. Check your connection and try again.", fromUser: false));
    }
  }

  // ------------------------------------------------------------
  // CALL EMERGENCY — actually opens the dialer, doesn't just say the number.
  // ------------------------------------------------------------

  Future<void> _handleCallEmergency(String number, String label) async {
    final opened = await EmergencyService.dial(number);
    _addBotMessage(ChatMessage(
      text: opened ? 'Opening your dialer for $label ($number)…' : "Couldn't open the dialer automatically — please dial $number ($label) yourself.",
      fromUser: false,
    ));
  }

  // ------------------------------------------------------------
  // MOBILE COMPLAINT — hands off to the complaint form.
  // ------------------------------------------------------------

  void _handleComplaint() {
    _addBotMessage(ChatMessage(
      text: "I'll open the complaint form — pick a category, describe what happened, and it'll send it by SMS with your location attached.",
      fromUser: false,
      actions: [
        ChatAction(
          label: 'Open complaint form',
          icon: Icons.edit_document,
          onTap: () {
            if (!mounted) return;
            Navigator.push(context, MaterialPageRoute(builder: (_) => const MobileComplaintScreen()));
          },
        ),
      ],
    ));
  }

  // ------------------------------------------------------------
  // CONTACTS — actually saves the contact, doesn't send you to Profile.
  // ------------------------------------------------------------

  Future<void> _handleAddContact(String name, String phone) async {
    final digits = phone.replaceAll(RegExp(r'[^0-9+]'), '');
    if (digits.length < 7) {
      _addBotMessage( ChatMessage(text: 'That phone number looks too short — could you send it again with the country code?', fromUser: false));
      return;
    }

    final prefs = await SharedPreferences.getInstance();
    final contacts = prefs.getStringList('contacts') ?? <String>[];
    contacts.add('$name|$digits');
    await prefs.setStringList('contacts', contacts);

    _addBotMessage(ChatMessage(
      text: '✅ Added $name ($digits) to your trusted contacts. I\'ll notify them automatically the next time you say "send sos".',
      fromUser: false,
    ));
  }

  Future<void> _handleListContacts() async {
    final contacts = await SosController.instance.loadContacts();
    if (contacts.isEmpty) {
      _addBotMessage( ChatMessage(
        text: "You don't have any trusted contacts yet. Tell me one, e.g. \"add contact Mom 9876543210\".",
        fromUser: false,
      ));
      return;
    }
    final list = contacts.map((c) => '${c.$1} (${c.$2})').join(', ');
    _addBotMessage(ChatMessage(text: 'Your trusted contacts: $list.', fromUser: false));
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Column(children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 14, 20, 6),
          child: Row(children: [
            Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('SAFETY ASSISTANT', style: TextStyle(color: muted, fontSize: 12, fontWeight: FontWeight.w500)),
              const SizedBox(height: 4),
              const Text('Ask SafeHer', style: TextStyle(color: ink, fontSize: 24, fontWeight: FontWeight.w700, letterSpacing: -.6)),
            ]),
            const Spacer(),
            Container(
              width: 42,
              height: 42,
              decoration: BoxDecoration(color: blush, borderRadius: BorderRadius.circular(15)),
              child: const Icon(Icons.smart_toy_outlined, color: plum, size: 19),
            ),
          ]),
        ),
        Expanded(
          child: ListView.builder(
            controller: _scrollController,
            padding: const EdgeInsets.fromLTRB(20, 8, 20, 8),
            itemCount: _messages.length + (_busy ? 1 : 0),
            itemBuilder: (context, index) {
              if (index >= _messages.length) return const _TypingBubble();
              return _Bubble(message: _messages[index]);
            },
          ),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 8, 20, 12),
          child: Row(children: [
            Expanded(
              child: Container(
                decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16), border: Border.all(color: border)),
                padding: const EdgeInsets.symmetric(horizontal: 14),
                child: TextField(
                  controller: _controller,
                  textInputAction: TextInputAction.send,
                  onSubmitted: (_) => _send(),
                  enabled: !_busy,
                  decoration: InputDecoration(
                    hintText: _pending == _Pending.routeDestination ? 'Where to?' : 'Try "send sos" or "route to…"',
                    border: InputBorder.none,
                    isDense: true,
                  ),
                  style: const TextStyle(fontSize: 13, color: ink),
                ),
              ),
            ),
            const SizedBox(width: 8),
            Container(
              decoration: BoxDecoration(color: plum, borderRadius: BorderRadius.circular(14)),
              child: IconButton(onPressed: _busy ? null : _send, icon: const Icon(Icons.arrow_upward_rounded, color: Colors.white)),
            ),
          ]),
        ),
      ]),
    );
  }
}

class _TypingBubble extends StatelessWidget {
  const _TypingBubble();

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: Alignment.centerLeft,
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 5),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16).copyWith(bottomLeft: const Radius.circular(4)), border: Border.all(color: border)),
        child: const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2, color: plum)),
      ),
    );
  }
}

class _Bubble extends StatelessWidget {
  const _Bubble({required this.message});

  final ChatMessage message;

  @override
  Widget build(BuildContext context) {
    final isUser = message.fromUser;
    return Align(
      alignment: isUser ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 5),
        constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * .82),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        decoration: BoxDecoration(
          color: isUser ? plum : Colors.white,
          borderRadius: BorderRadius.circular(16).copyWith(
            bottomRight: isUser ? const Radius.circular(4) : null,
            bottomLeft: !isUser ? const Radius.circular(4) : null,
          ),
          border: isUser ? null : Border.all(color: border),
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(message.text, style: TextStyle(color: isUser ? Colors.white : ink, fontSize: 13, height: 1.4)),
          if (!isUser && message.route != null) ...[
            const SizedBox(height: 10),
            ClipRRect(
              borderRadius: BorderRadius.circular(14),
              child: SizedBox(height: 140, width: double.infinity, child: RouteMapView(route: message.route, compact: true)),
            ),
          ],
          if (!isUser && message.route == null && message.havens != null) ...[
            const SizedBox(height: 10),
            ClipRRect(
              borderRadius: BorderRadius.circular(14),
              child: SizedBox(
                height: 140,
                width: double.infinity,
                child: RouteMapView(havens: message.havens, center: message.mapCenter, liveLatLng: message.mapCenter, compact: true),
              ),
            ),
          ],
          if (!isUser && message.actions != null && message.actions!.isNotEmpty) ...[
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              runSpacing: 6,
              children: message.actions!
                  .map((action) => OutlinedButton.icon(
                        onPressed: action.onTap,
                        icon: Icon(action.icon ?? Icons.arrow_forward_rounded, size: 15, color: coral),
                        label: Text(action.label, style: const TextStyle(color: coral, fontWeight: FontWeight.w700, fontSize: 11)),
                        style: OutlinedButton.styleFrom(
                          side: const BorderSide(color: Color(0xFFE3B4BF)),
                          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                          minimumSize: Size.zero,
                          tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                        ),
                      ))
                  .toList(),
            ),
          ],
        ]),
      ),
    );
  }
}

/// Read-only full-screen preview of a route the chatbot just fetched: the
/// map, and the same turn-by-turn steps the Safe Paths tab would show.
class _RoutePreviewScreen extends StatelessWidget {
  const _RoutePreviewScreen({required this.route, required this.destinationLabel});

  final SafeRoute route;
  final String destinationLabel;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: background,
      body: SafeArea(
        child: Column(children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 8, 20, 6),
            child: Row(children: [
              IconButton(onPressed: () => Navigator.pop(context), icon: const Icon(Icons.arrow_back_rounded, color: ink)),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  const Text('ROUTE TO', style: TextStyle(color: muted, fontSize: 11, fontWeight: FontWeight.w700, letterSpacing: 1)),
                  Text(destinationLabel, style: const TextStyle(color: ink, fontSize: 19, fontWeight: FontWeight.w700), overflow: TextOverflow.ellipsis),
                ]),
              ),
            ]),
          ),
          SizedBox(
            height: 260,
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: ClipRRect(borderRadius: BorderRadius.circular(20), child: RouteMapView(route: route)),
            ),
          ),
          const SizedBox(height: 14),
          Expanded(
            child: ListView(
              padding: const EdgeInsets.fromLTRB(20, 0, 20, 24),
              children: [
                SoftCard(
                  color: plum,
                  child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                    Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(route.name, style: const TextStyle(color: Colors.white, fontSize: 15, fontWeight: FontWeight.w700)),
                      const SizedBox(height: 3),
                      Text('${route.distanceLabel} · ${route.durationLabel}', style: const TextStyle(color: Color(0xFFEEDCE9), fontSize: 11)),
                    ]),
                    Text('${route.safetyScore}%', style: const TextStyle(color: blushStrong, fontSize: 22, fontWeight: FontWeight.w800)),
                  ]),
                ),
                const SizedBox(height: 14),
                const SectionHeading(eyebrow: 'DIRECTIONS', title: 'Step by step'),
                SoftCard(
                  child: Column(
                    children: route.steps.asMap().entries.map((entry) {
                      return Container(
                        padding: const EdgeInsets.symmetric(vertical: 10),
                        decoration: BoxDecoration(
                          border: entry.key < route.steps.length - 1 ? const Border(bottom: BorderSide(color: Color(0xFFF5EDF0))) : null,
                        ),
                        child: Row(children: [
                          Container(
                            width: 22,
                            height: 22,
                            decoration: BoxDecoration(color: const Color(0xFFF4EBED), borderRadius: BorderRadius.circular(8)),
                            alignment: Alignment.center,
                            child: Text('${entry.key + 1}', style: const TextStyle(color: muted, fontSize: 9, fontWeight: FontWeight.w800)),
                          ),
                          const SizedBox(width: 10),
                          Expanded(child: Text(entry.value, style: const TextStyle(color: Color(0xFF6F626D), fontSize: 11, height: 1.4))),
                        ]),
                      );
                    }).toList(),
                  ),
                ),
              ],
            ),
          ),
        ]),
      ),
    );
  }
}
