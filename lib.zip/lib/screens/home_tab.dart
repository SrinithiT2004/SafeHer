import 'dart:async';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:latlong2/latlong.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../services/location_service.dart';
import '../services/safety_stats_service.dart';
import '../services/sms_service.dart';
import '../services/sos_controller.dart';
import '../services/emergency_service.dart';
import '../theme.dart';
import '../widgets/route_map.dart';
import '../widgets/shared_widgets.dart';
import 'safe_havens_screen.dart';
import 'mobile_complaint_screen.dart';

class HomeTab extends StatefulWidget {
  const HomeTab({
    super.key,
    required this.onPlan,
    required this.onInsights,
  });

  final VoidCallback onPlan;
  final VoidCallback onInsights;

  @override
  State<HomeTab> createState() => _HomeTabState();
}

class _HomeTabState extends State<HomeTab> {
  bool locationReady = false;

  StreamSubscription<ServiceStatus>? _serviceSub;
  bool _askedToOpenSettings = false;

  Position? currentPosition;

  String userName = 'there';

  final SosController _sos = SosController.instance;

  SafetySnapshot _snapshot = SafetySnapshot.empty;

  @override
  void initState() {
    super.initState();
    _loadUserName();
    _loadSnapshot();
    _sos.addListener(_onSosChanged);
    SafetyStatsService.revision.addListener(_loadSnapshot);
    // Location is requested automatically as soon as the app opens — no
    // "Enable" tap needed.
    WidgetsBinding.instance.addPostFrameCallback((_) => _autoEnableLocation());
    // If GPS was off and the user switches it on later, pick it up
    // automatically instead of asking them to come back and tap something.
    _serviceSub = Geolocator.getServiceStatusStream().listen((status) {
      if (status == ServiceStatus.enabled && !locationReady) {
        _autoEnableLocation();
      }
    });
  }

  // ------------------------------------------------------------
  // LOAD SAFETY SNAPSHOT — real trip history + SOS + contacts, not a
  // hardcoded score. Reloaded on every return to Home so a trip finished on
  // the Safe paths tab is reflected immediately.
  // ------------------------------------------------------------

  Future<void> _loadSnapshot() async {
    final snapshot = await SafetyStatsService.loadSnapshot();
    if (!mounted) return;
    setState(() => _snapshot = snapshot);
  }

  @override
  void dispose() {
    _serviceSub?.cancel();
    _sos.removeListener(_onSosChanged);
    SafetyStatsService.revision.removeListener(_loadSnapshot);
    super.dispose();
  }

  void _onSosChanged() {
    if (mounted) setState(() {});
  }

  // ------------------------------------------------------------
  // LOAD USER NAME
  // ------------------------------------------------------------

  Future<void> _loadUserName() async {
    final prefs = await SharedPreferences.getInstance();

    if (!mounted) return;

    final saved = prefs.getString('name') ?? 'Lina Menon';

    setState(() {
      userName = saved.trim().isEmpty
          ? 'there'
          : saved.trim().split(' ').first;
    });
  }

  // ------------------------------------------------------------
  // ENABLE / REFRESH LOCATION
  // ------------------------------------------------------------

  /// Runs on app open. Asks for the location permission straight away and
  /// fetches a fix. If phone GPS is switched off (Android/iOS don't allow an
  /// app to flip it silently), it opens the phone's Location settings once.
  Future<void> _autoEnableLocation() async {
    final result = await LocationService.ensurePermission();
    if (!mounted) return;

    if (result == LocationPermissionResult.serviceDisabled) {
      if (!_askedToOpenSettings) {
        _askedToOpenSettings = true;
        await Geolocator.openLocationSettings();
      }
      return;
    }

    if (result == LocationPermissionResult.deniedForever) {
      if (!_askedToOpenSettings) {
        _askedToOpenSettings = true;
        await Geolocator.openAppSettings();
      }
      return;
    }

    if (result != LocationPermissionResult.granted) return;

    final position = await LocationService.currentPosition();
    if (!mounted || position == null) return;

    setState(() {
      locationReady = true;
      currentPosition = position;
    });
  }

  /// Manual refresh (kept for the Refresh button once location is live).
  Future<void> enableLocation() async {
    final position =
        await LocationService.currentPosition();

    if (!mounted) return;

    if (position == null) {
      final result =
          await LocationService.ensurePermission();

      if (!mounted) return;

      final message =
          LocationService.messageFor(result);

      showAppDialog(
        context,
        'Location unavailable',
        message.isEmpty
            ? 'The phone could not get a GPS position. '
                'Make sure GPS is enabled and try again.'
            : message,
      );

      return;
    }

    if (!mounted) return;

    setState(() {
      locationReady = true;
      currentPosition = position;
    });
  }

  // ------------------------------------------------------------
  // ACTIVATE SOS
  //
  // Delegates to the shared SosController so this button behaves exactly
  // the same as triggering "send sos" from the chatbot — one live-location
  // stream, one set of SMS updates, no matter where it was started from.
  // ------------------------------------------------------------

  Future<void> _activateSos() async {
    final result = await _sos.activate();

    if (!mounted) return;

    if (result.isOk) {
      final missingPhone = await _sos.countContactsWithoutPhone();
      if (!mounted) return;
      setState(() {
        locationReady = true;
        currentPosition = _sos.currentPosition;
      });
      _showSosOutcome(result.sendResult!, missingPhoneCount: missingPhone);
      return;
    }

    switch (result.failure) {
      case SosStartFailure.permission:
        showAppDialog(context, 'Location needed for SOS', result.failureMessage ?? '');
        break;
      case SosStartFailure.gps:
        showAppDialog(context, 'SOS could not start', result.failureMessage ?? '');
        break;
      case SosStartFailure.alreadyStarting:
      case null:
        break;
    }
  }

  // ------------------------------------------------------------
  // SHOW SOS RESULT
  // ------------------------------------------------------------

  void _showSosOutcome(SosSendResult result, {int missingPhoneCount = 0}) {
    if (!mounted) return;

    switch (result.outcome) {
      case SosSendOutcome.sentDirectly:
        final attempted = result.sent.length + result.failed.length;
        final notes = <String>[];
        if (result.failed.isNotEmpty) {
          notes.add('${result.failed.length} of your saved numbers could not be reached.');
        }
        if (missingPhoneCount > 0) {
          notes.add(
            '$missingPhoneCount trusted contact(s) have no phone number saved, '
            'so they were skipped — add one in the Profile tab.',
          );
        }
        showAppDialog(
          context,
          'SOS activated',
          'Your live location was sent automatically to '
              '${result.sent.length}${attempted != result.sent.length ? ' of $attempted' : ''} '
              'contact(s) — no extra tap needed. '
              'It will keep updating them while SOS stays active.'
              '${notes.isEmpty ? '' : '\n\n${notes.join(' ')}'}',
        );
        break;

      case SosSendOutcome.openedComposer:
        showAppDialog(
          context,
          'SOS activated',
          Platform.isIOS
              ? "Your live location is now tracking. "
                  "iOS doesn't allow apps to send texts silently "
                  "for privacy reasons, so your messaging app opened "
                  "prefilled — just tap Send."
              : 'Your live location is now tracking. '
                  'SafeHer opened your messaging app prefilled '
                  'because SMS permission was not granted — '
                  'allow it in Settings to send automatically next time.',
        );
        break;

      case SosSendOutcome.noContacts:
        showAppDialog(
          context,
          'SOS activated',
          'Your live location is now being tracked on this device. '
              'Add phone numbers to your trusted contacts '
              '(Profile tab) so SOS can alert them automatically.',
        );
        break;

      case SosSendOutcome.failed:
        showAppDialog(
          context,
          'SOS activated, message not sent',
          'Your live location is tracking on this device, '
              'but the alert could not be sent. '
              'Please call your contacts directly if possible.',
        );
        break;
    }
  }

  // ------------------------------------------------------------
  // STOP SOS
  // ------------------------------------------------------------

  Future<void> _stopSos() async {
    await _sos.stop();

    if (!mounted) return;

    showAppDialog(
      context,
      'SOS stopped',
      'Live location tracking has been stopped.',
    );
  }

  // ------------------------------------------------------------
  // EMERGENCY DIAL — calls directly from SafeHer where the OS allows it,
  // instead of just opening the phone app.
  // ------------------------------------------------------------

  Future<void> _callEmergencyNumber(EmergencyNumber e) async {
    final result = await EmergencyService.call(e.number);
    if (!mounted) return;
    switch (result) {
      case CallResult.calledDirectly:
        break; // The call is already ringing — no dialog needed.
      case CallResult.openedDialer:
        showAppDialog(
          context,
          'Dialer opened',
          Platform.isIOS
              ? "iOS doesn't allow apps to place calls silently, so your "
                  "dialer opened with ${e.label} ready — just tap the call button."
              : 'SafeHer opened your dialer with ${e.label} ready because call '
                  'permission was not granted — allow it in Settings to call '
                  'directly from the app next time.',
        );
        break;
      case CallResult.failed:
        showAppDialog(context, "Couldn't place the call", 'Please try again, or dial ${e.number} manually.');
        break;
    }
  }

  // ------------------------------------------------------------
  // TODAY'S DATE
  // ------------------------------------------------------------

  String _todayLabel() {
    const weekdays = [
      'Monday',
      'Tuesday',
      'Wednesday',
      'Thursday',
      'Friday',
      'Saturday',
      'Sunday',
    ];

    const months = [
      'January',
      'February',
      'March',
      'April',
      'May',
      'June',
      'July',
      'August',
      'September',
      'October',
      'November',
      'December',
    ];

    final now = DateTime.now();

    return '${weekdays[now.weekday - 1]}, '
        '${now.day} ${months[now.month - 1]}';
  }

  // ------------------------------------------------------------
  // BUILD
  // ------------------------------------------------------------

  @override
  Widget build(BuildContext context) {
    return AppScroll(
      children: [
        // --------------------------------------------------------
        // HEADER
        // --------------------------------------------------------

        Header(
          eyebrow: _todayLabel(),
          title: 'Good day, $userName',
          initials: userName.isEmpty
              ? 'SH'
              : userName.substring(0, 1).toUpperCase(),
        ),

        const SizedBox(height: 16),

        // --------------------------------------------------------
        // SOS CARD — big and first, so it's the first thing on screen.
        // --------------------------------------------------------

        Container(
          decoration: BoxDecoration(
            color: const Color(0xFFFFE3E8),
            borderRadius: BorderRadius.circular(22),
            border: Border.all(color: sosRed, width: 2.5),
            boxShadow: [
              BoxShadow(
                color: sosRed.withValues(alpha: .35),
                blurRadius: 20,
                spreadRadius: 1,
                offset: const Offset(0, 6),
              ),
            ],
          ),
          padding: const EdgeInsets.all(18),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Row(
                children: [
                  Container(
                    width: 60,
                    height: 60,
                    decoration: BoxDecoration(
                      color: sosRed,
                      borderRadius: BorderRadius.circular(18),
                      boxShadow: [
                        BoxShadow(
                          color: sosRed.withValues(alpha: .5),
                          blurRadius: 12,
                          spreadRadius: 1,
                        ),
                      ],
                    ),
                    child: Icon(
                      _sos.active ? Icons.location_searching_rounded : Icons.sos_rounded,
                      color: Colors.white,
                      size: 32,
                    ),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          _sos.active ? 'SOS is active' : 'Emergency SOS',
                          style: const TextStyle(color: plum, fontSize: 19, fontWeight: FontWeight.w900),
                        ),
                        const SizedBox(height: 3),
                        Text(
                          _sos.active
                              ? 'Live GPS location is updating with your contacts.'
                              : 'One tap sends your live location to trusted contacts.',
                          style: const TextStyle(color: Color(0xFF7A4A52), fontSize: 12.5),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 20),
              LayoutBuilder(
                builder: (context, constraints) {
                  final double size = constraints.maxWidth.clamp(0, 360);
                  return Center(
                    child: SizedBox(
                      width: size,
                      height: size,
                      child: Material(
                        color: Colors.transparent,
                        shape: const CircleBorder(
                          side: BorderSide(color: plum, width: 6),
                        ),
                        elevation: 10,
                        shadowColor: sosRed.withValues(alpha: .7),
                        child: InkWell(
                          customBorder: const CircleBorder(),
                          onTap: _sos.busy ? null : (_sos.active ? _stopSos : _activateSos),
                          child: Ink(
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: sosRed,
                              boxShadow: [
                                BoxShadow(
                                  color: sosRed.withValues(alpha: .55),
                                  blurRadius: 34,
                                  spreadRadius: 4,
                                ),
                              ],
                            ),
                            child: Center(
                              child: _sos.busy
                                  ? const SizedBox(
                                      width: 44,
                                      height: 44,
                                      child: CircularProgressIndicator(strokeWidth: 3.5, color: Colors.white),
                                    )
                                  : Text(
                                      _sos.active ? 'STOP' : 'SOS',
                                      style: TextStyle(
                                        color: Colors.white,
                                        fontSize: size * 0.24,
                                        fontWeight: FontWeight.w900,
                                        letterSpacing: 2,
                                      ),
                                    ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  );
                },
              ),
              const SizedBox(height: 16),
              Center(
                child: Text(
                  _sos.active
                      ? 'Tap to stop sending your live location.'
                      : 'PRESS THE BUTTON IN CASE OF EMERGENCY',
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    color: Color(0xFF7A4A52),
                    fontSize: 13,
                    fontWeight: FontWeight.w700,
                    letterSpacing: .3,
                  ),
                ),
              ),
            ],
          ),
        ),

        if (_sos.active && _sos.currentPosition != null) ...[
          const SizedBox(height: 12),
          const SectionHeading(eyebrow: 'LIVE LOCATION', title: 'Your position now'),
          SizedBox(
            height: 280,
            child: RouteMapView(
              liveLatLng: LatLng(_sos.currentPosition!.latitude, _sos.currentPosition!.longitude),
            ),
          ),
        ],

        const SizedBox(height: 18),

        // --------------------------------------------------------
        // SAFEHER PROTECTION CARD
        // --------------------------------------------------------

        Card(
          color: plum,
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Row(
              crossAxisAlignment:
                  CrossAxisAlignment.end,
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment:
                        CrossAxisAlignment.start,
                    children: [
                      const Row(
                        children: [
                          Icon(
                            Icons.shield_outlined,
                            color: blushStrong,
                            size: 15,
                          ),
                          SizedBox(width: 7),
                          Text(
                            'SAFEHER PROTECTION',
                            style: TextStyle(
                              color: blushStrong,
                              fontSize: 10,
                              fontWeight: FontWeight.w800,
                              letterSpacing: 1.1,
                            ),
                          ),
                        ],
                      ),

                      const SizedBox(height: 15),

                      const Text(
                        'Feel safer on the way home.',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 26,
                          height: 1.18,
                          fontWeight: FontWeight.w700,
                        ),
                      ),

                      const SizedBox(height: 10),

                      const Text(
                        'We plan real routes and surface nearby '
                        'safety havens — not just the fastest way.',
                        style: TextStyle(
                          color: Color(0xFFEEDCE9),
                          fontSize: 13,
                          height: 1.45,
                        ),
                      ),

                      const SizedBox(height: 18),

                      FilledButton.icon(
                        onPressed: widget.onPlan,
                        icon: const Icon(
                          Icons.arrow_outward_rounded,
                          size: 16,
                        ),
                        label: const Text(
                          'Plan a safe path',
                        ),
                        style: FilledButton.styleFrom(
                          backgroundColor: blushStrong,
                          foregroundColor: plum,
                          padding:
                              const EdgeInsets.symmetric(
                            horizontal: 13,
                            vertical: 11,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),

                const SizedBox(width: 12),

                Container(
                  width: 54,
                  height: 54,
                  decoration: BoxDecoration(
                    border: Border.all(
                      color: const Color(0xFF84577B),
                    ),
                    borderRadius:
                        BorderRadius.circular(18),
                  ),
                  child: const Icon(
                    Icons.navigation_outlined,
                    color: blushStrong,
                    size: 28,
                  ),
                ),
              ],
            ),
          ),
        ),

        const SizedBox(height: 14),

        // --------------------------------------------------------
        // LOCATION CARD
        // --------------------------------------------------------

        SoftCard(
          color: blush,
          child: Row(
            children: [
              const SoftIcon(
                icon: Icons.location_on_outlined,
                color: plum,
              ),

              const SizedBox(width: 11),

              Expanded(
                child: Column(
                  crossAxisAlignment:
                      CrossAxisAlignment.start,
                  children: [
                    Text(
                      locationReady
                          ? 'Live location ready'
                          : 'Turning on your location…',
                      style: const TextStyle(
                        color: plum,
                        fontSize: 13,
                        fontWeight: FontWeight.w700,
                      ),
                    ),

                    Text(
                      locationReady
                          ? currentPosition == null
                              ? 'GPS is ready'
                              : '${currentPosition!.latitude.toStringAsFixed(5)}, '
                                '${currentPosition!.longitude.toStringAsFixed(5)}'
                          : 'Allow location access if your phone asks',
                      style: const TextStyle(
                        color: muted,
                        fontSize: 11,
                      ),
                    ),
                  ],
                ),
              ),

              locationReady
                  ? IconButton(
                      tooltip: 'Refresh location',
                      onPressed: enableLocation,
                      icon: const Icon(Icons.refresh_rounded, color: plum),
                    )
                  : const Padding(
                      padding: EdgeInsets.all(12),
                      child: SizedBox(
                        width: 18,
                        height: 18,
                        child: CircularProgressIndicator(strokeWidth: 2, color: plum),
                      ),
                    ),
            ],
          ),
        ),

        const SizedBox(height: 14),

        // --------------------------------------------------------
        // SAFE HAVENS QUICK ACCESS
        // --------------------------------------------------------

        GestureDetector(
          onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const SafeHavensScreen())),
          child: SoftCard(
            color: greenSoft,
            child: Row(
              children: [
                const SoftIcon(icon: Icons.shield_outlined, color: green),
                const SizedBox(width: 11),
                const Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Safe havens near you', style: TextStyle(color: green, fontSize: 13, fontWeight: FontWeight.w800)),
                      SizedBox(height: 3),
                      Text('Police, hospitals & pharmacies pinned on the map', style: TextStyle(color: Color(0xFF5D8C7B), fontSize: 11)),
                    ],
                  ),
                ),
                const Icon(Icons.chevron_right, color: muted),
              ],
            ),
          ),
        ),

        const SizedBox(height: 14),

        // --------------------------------------------------------
        // EMERGENCY DIAL — national helpline numbers, one tap to call.
        // --------------------------------------------------------

        Container(
          decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(20), border: Border.all(color: border)),
          padding: const EdgeInsets.all(14),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Row(
                children: [
                  Container(
                    width: 40,
                    height: 40,
                    decoration: BoxDecoration(color: greenSoft, borderRadius: BorderRadius.circular(13)),
                    child: const Icon(Icons.call_rounded, color: green, size: 20),
                  ),
                  const SizedBox(width: 11),
                  const Expanded(
                    child: Text('Emergency dial', style: TextStyle(color: ink, fontSize: 14, fontWeight: FontWeight.w800)),
                  ),
                ],
              ),
              const SizedBox(height: 4),
              const Text('Calls directly from SafeHer — no dialer, no contacts app.', style: TextStyle(color: muted, fontSize: 11)),
              const SizedBox(height: 12),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: indiaEmergencyNumbers
                    .map((e) => OutlinedButton.icon(
                          onPressed: () => _callEmergencyNumber(e),
                          icon: const Icon(Icons.call_outlined, size: 15, color: green),
                          label: Text(e.label, style: const TextStyle(color: green, fontWeight: FontWeight.w700, fontSize: 11.5)),
                          style: OutlinedButton.styleFrom(side: const BorderSide(color: Color(0xFFBFE0D2)), padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8)),
                        ))
                    .toList(),
              ),
            ],
          ),
        ),

        const SizedBox(height: 14),

        // --------------------------------------------------------
        // MOBILE COMPLAINT QUICK ACCESS
        // --------------------------------------------------------

        GestureDetector(
          onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const MobileComplaintScreen())),
          child: SoftCard(
            color: const Color(0xFFF4EBED),
            child: Row(
              children: [
                const SoftIcon(icon: Icons.edit_document, color: plum),
                const SizedBox(width: 11),
                const Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Mobile complaint', style: TextStyle(color: plum, fontSize: 13, fontWeight: FontWeight.w800)),
                      SizedBox(height: 3),
                      Text('File what happened, with your location, directly from SafeHer', style: TextStyle(color: Color(0xFF7A5E70), fontSize: 11)),
                    ],
                  ),
                ),
                const Icon(Icons.chevron_right, color: muted),
              ],
            ),
          ),
        ),

        const SizedBox(height: 22),

        // --------------------------------------------------------
        // SAFETY SNAPSHOT
        // --------------------------------------------------------

        SectionHeading(
          eyebrow: 'YOUR SAFETY SNAPSHOT',
          title: 'Protected trips',
          action: TextButton(
            onPressed: widget.onInsights,
            child: const Text(
              'See insights',
              style: TextStyle(
                color: coral,
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
        ),

        SoftCard(
          child: !_snapshot.hasData
              ? Padding(
                  padding: const EdgeInsets.symmetric(vertical: 10),
                  child: Row(
                    children: [
                      Container(
                        width: 40,
                        height: 40,
                        decoration: BoxDecoration(color: blush, borderRadius: BorderRadius.circular(13)),
                        child: const Icon(Icons.route_outlined, color: plum, size: 19),
                      ),
                      const SizedBox(width: 11),
                      const Expanded(
                        child: Text(
                          'Finish your first trip with SafeHer guidance to start building your safety score.',
                          style: TextStyle(color: muted, fontSize: 11.5, height: 1.4),
                        ),
                      ),
                    ],
                  ),
                )
              : Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              '${_snapshot.overallScore}',
                              style: const TextStyle(color: ink, fontSize: 38, fontWeight: FontWeight.w700),
                            ),
                            const Text('safety score', style: TextStyle(color: muted, fontSize: 11)),
                          ],
                        ),
                        if (_snapshot.trendPercent != null)
                          Container(
                            decoration: BoxDecoration(
                              color: _snapshot.trendPercent! >= 0 ? greenSoft : const Color(0xFFFCE4E4),
                              borderRadius: BorderRadius.circular(10),
                            ),
                            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
                            child: Row(
                              children: [
                                Icon(
                                  _snapshot.trendPercent! >= 0 ? Icons.trending_up : Icons.trending_down,
                                  color: _snapshot.trendPercent! >= 0 ? green : sosRed,
                                  size: 14,
                                ),
                                const SizedBox(width: 5),
                                Text(
                                  '${_snapshot.trendPercent! >= 0 ? '+' : ''}${_snapshot.trendPercent!.round()}% this week',
                                  style: TextStyle(
                                    color: _snapshot.trendPercent! >= 0 ? green : sosRed,
                                    fontSize: 10,
                                    fontWeight: FontWeight.w700,
                                  ),
                                ),
                              ],
                            ),
                          ),
                      ],
                    ),
                    const SizedBox(height: 18),
                    SizedBox(height: 94, child: MiniBars(values: _snapshot.weekly)),
                    const Divider(color: Color(0xFFF2E9EC)),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Expanded(
                          child: Text(
                            'Last trip · ${_snapshot.lastTrip!.source} → ${_snapshot.lastTrip!.destination}',
                            style: const TextStyle(color: muted, fontSize: 10),
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                        const SizedBox(width: 8),
                        Text(_snapshot.lastTrip!.durationLabel, style: const TextStyle(color: muted, fontSize: 10)),
                      ],
                    ),
                  ],
                ),
        ),

        const SizedBox(height: 22),

        // --------------------------------------------------------
        // NEXT TRIP
        // --------------------------------------------------------

        const SectionHeading(
          eyebrow: 'NEXT TRIP',
          title: 'A safer way to go',
        ),

        GestureDetector(
          onTap: widget.onPlan,
          child: SoftCard(
            child: Column(
              children: [
                Row(
                  mainAxisAlignment:
                      MainAxisAlignment.spaceBetween,
                  children: [
                    const Expanded(
                      child: Column(
                        crossAxisAlignment:
                            CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Plan your next trip',
                            style: TextStyle(
                              color: ink,
                              fontSize: 14,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                          SizedBox(height: 4),
                          Text(
                            'Enter a start and destination for a real, live-routed path',
                            style: TextStyle(
                              color: muted,
                              fontSize: 11,
                            ),
                          ),
                        ],
                      ),
                    ),

                    const SizedBox(width: 10),

                    Container(
                      width: 47,
                      height: 47,
                      decoration: BoxDecoration(
                        color: blush,
                        borderRadius:
                            BorderRadius.circular(15),
                      ),
                      child: const Icon(
                        Icons.chevron_right_rounded,
                        color: plum,
                      ),
                    ),
                  ],
                ),

                const SizedBox(height: 12),

                const SizedBox(
                  height: 150,
                  child: RouteMapView(
                    compact: true,
                    emptyHint:
                        'Plan a path to preview it here',
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}