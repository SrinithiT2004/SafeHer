import 'package:flutter/material.dart';

import '../services/live_safety_service.dart';
import '../services/safety_stats_service.dart';
import '../theme.dart';
import '../widgets/shared_widgets.dart';
import 'safe_havens_screen.dart';

/// Built entirely from this user's own data — completed trips, SOS
/// activations, and trusted contacts — via SafetyStatsService. Nothing here
/// is hardcoded; an empty state shows until the user has finished at least
/// one trip.
class InsightsTab extends StatefulWidget {
  const InsightsTab({super.key});

  @override
  State<InsightsTab> createState() => _InsightsTabState();
}

class _InsightsTabState extends State<InsightsTab> {
  SafetySnapshot _snapshot = SafetySnapshot.empty;

  @override
  void initState() {
    super.initState();
    _load();
    SafetyStatsService.revision.addListener(_load);
    LiveSafetyService.state.addListener(_onLive);
  }

  void _onLive() {
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    SafetyStatsService.revision.removeListener(_load);
    LiveSafetyService.state.removeListener(_onLive);
    super.dispose();
  }

  Future<void> _load() async {
    final snapshot = await SafetyStatsService.loadSnapshot();
    if (!mounted) return;
    setState(() => _snapshot = snapshot);
  }

  @override
  Widget build(BuildContext context) {
    final snapshot = _snapshot;

    final live = LiveSafetyService.state.value;

    // Live headline score: from the phone's GPS when available, otherwise
    // fall back to the trip-history score.
    final headlineScore = live.score ?? snapshot.overallScore;
    final hasHeadline = live.score != null || snapshot.hasData;

    // Confidence over time: stored live daily averages, today's bar is the
    // current live score. Days with no live data fall back to trip history.
    final today = DateTime.now();
    final bars = <int>[];
    final labels = <String>[];
    for (var i = 0; i < 7; i++) {
      final day = DateTime(today.year, today.month, today.day).subtract(Duration(days: 6 - i));
      labels.add(const ['M', 'T', 'W', 'T', 'F', 'S', 'S'][day.weekday - 1]);
      var value = live.dailyAverages[i];
      if (value == 0 && snapshot.hasData) value = snapshot.weekly[i];
      if (i == 6 && live.score != null) value = live.score!;
      bars.add(value);
    }

    // Trend: live score vs the average of the previous days that have data.
    final earlier = live.dailyAverages.sublist(0, 6).where((v) => v > 0).toList();
    double? trend;
    if (live.score != null && earlier.isNotEmpty) {
      trend = live.score! - earlier.reduce((a, b) => a + b) / earlier.length;
    } else {
      trend = snapshot.trendPercent;
    }

    String nearestLabel() {
      final m = live.nearestHavenMeters;
      if (m == null) return 'searching for havens…';
      return m >= 1000 ? 'nearest ${(m / 1000).toStringAsFixed(1)} km' : 'nearest ${m.round()} m';
    }

    // Every signal below is recomputed live from GPS, the clock, or the
    // user's data — nothing is a fixed number.
    final factors = [
      (
        'Safety havens nearby',
        live.tracking ? live.havenFactor : snapshot.havenFactor,
        green,
        Icons.shield_outlined,
        live.tracking ? '${live.havensNearby} within 1.5 km · ${nearestLabel()}' : 'Turn on location for live havens',
      ),
      (
        'Trusted contacts ready',
        live.contactsFactor,
        coral,
        Icons.people_outline,
        live.contactsFactor >= 100 ? 'Two or more contacts can be alerted' : live.contactsFactor > 0 ? 'Add one more contact for full cover' : 'Add a contact with a phone number',
      ),
      (
        'Time of day',
        live.timeFactor,
        plum,
        Icons.wb_twilight_outlined,
        live.timeFactor >= 100 ? 'Daytime — best visibility' : live.timeFactor >= 60 ? 'Evening — stay on lit routes' : 'Late hours — take extra care',
      ),
      (
        'Movement',
        live.movementFactor,
        const Color(0xFF5B8DEF),
        Icons.directions_walk_outlined,
        !live.tracking
            ? 'Waiting for GPS'
            : live.stationaryMinutes < 2
                ? 'You are on the move'
                : 'Staying in one place for ${live.stationaryMinutes} min',
      ),
      (
        'Safer routes chosen',
        snapshot.goodRouteFactor,
        gold,
        Icons.alt_route_outlined,
        snapshot.hasData ? 'Trips on routes scored 80+' : 'Complete a trip to fill this in',
      ),
    ];

    return AppScroll(children: [
      const Header(eyebrow: 'YOUR PATTERNS', title: 'Safety insights', icon: Icons.bar_chart_outlined),
      Text(
        snapshot.hasData
            ? 'A view of what has made your ${snapshot.tripCount} completed trip${snapshot.tripCount == 1 ? '' : 's'} feel safer.'
            : 'Finish a trip with SafeHer guidance and this page fills in with your own patterns.',
        style: const TextStyle(color: muted, fontSize: 13, height: 1.45),
      ),
      SoftCard(
        color: plum,
        child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(live.tracking ? 'LIVE CONFIDENCE' : 'CONFIDENCE', style: TextStyle(color: Color(0xFFD9B5D2), fontSize: 9, letterSpacing: 1, fontWeight: FontWeight.w800)),
            const SizedBox(height: 4),
            Text.rich(TextSpan(text: '$headlineScore', style: const TextStyle(color: Colors.white, fontSize: 44, fontWeight: FontWeight.w700), children: const [
              TextSpan(text: '/100', style: TextStyle(color: Color(0xFFD9B5D2), fontSize: 17, fontWeight: FontWeight.w600)),
            ])),
            const SizedBox(height: 4),
            if (trend != null)
              Row(children: [
                Icon(trend >= 0 ? Icons.arrow_upward_rounded : Icons.arrow_downward_rounded, color: const Color(0xFFA9E0CC), size: 12),
                const SizedBox(width: 4),
                Text('${trend.abs().round()} points ${live.score != null ? 'vs your recent days' : 'from last week'}', style: const TextStyle(color: Color(0xFFA9E0CC), fontSize: 10, fontWeight: FontWeight.w700)),
              ])
            else
              Text(
                live.tracking ? 'Updating live as you move' : (snapshot.hasData ? 'Complete a trip next week to see a trend' : 'Turn on location for a live score'),
                style: const TextStyle(color: Color(0xFFA9E0CC), fontSize: 10, fontWeight: FontWeight.w700),
              ),
          ]),
          Container(
            width: 86,
            height: 86,
            decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: coral, width: 7)),
            child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
              const Icon(Icons.shield_outlined, color: coral, size: 22),
              const SizedBox(height: 2),
              Text(
                headlineScore >= 80
                    ? 'GOOD'
                    : headlineScore >= 55
                        ? 'OK'
                        : hasHeadline
                            ? 'LOW'
                            : '—',
                style: const TextStyle(color: blushStrong, fontSize: 8, fontWeight: FontWeight.w800, letterSpacing: .7),
              ),
            ]),
          ),
        ]),
      ),
      const SizedBox(height: 4),
      const SectionHeading(eyebrow: 'LAST 7 DAYS', title: 'Confidence over time'),
      SoftCard(
        child: Column(children: [
          SizedBox(
            height: 155,
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: bars.asMap().entries.map((entry) {
                return Expanded(
                  child: Column(mainAxisAlignment: MainAxisAlignment.end, children: [
                    Expanded(
                      child: Align(
                        alignment: Alignment.bottomCenter,
                        child: FractionallySizedBox(
                          heightFactor: (entry.value / 100).clamp(0.02, 1.0),
                          child: Container(
                            width: 17,
                            decoration: BoxDecoration(
                              color: entry.key == bars.length - 1 ? coral : const Color(0xFFF2C7D1),
                              borderRadius: BorderRadius.circular(9),
                            ),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(height: 9),
                    Text(
                      labels[entry.key],
                      style: TextStyle(color: entry.key == bars.length - 1 ? coral : const Color(0xFFA2949E), fontSize: 10, fontWeight: FontWeight.w600),
                    ),
                  ]),
                );
              }).toList(),
            ),
          ),
          const SizedBox(height: 12),
          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            const Text('More protected', style: TextStyle(color: Color(0xFFA2949E), fontSize: 10)),
            Text(LiveSafetyService.state.value.tracking ? 'Today · live' : 'Today', style: const TextStyle(color: Color(0xFFA2949E), fontSize: 10)),
          ]),
        ]),
      ),
      const SizedBox(height: 4),
      const SectionHeading(eyebrow: 'WHAT HELPS MOST', title: 'Your route signals'),
      SoftCard(
        child: Column(
          children: factors.asMap().entries.map((entry) {
            final factor = entry.value;
            return Container(
              padding: const EdgeInsets.symmetric(vertical: 14),
              decoration: BoxDecoration(border: entry.key < factors.length - 1 ? const Border(bottom: BorderSide(color: Color(0xFFF5EDF0))) : null),
              child: Row(children: [
                Container(width: 36, height: 36, decoration: BoxDecoration(color: factor.$3.withValues(alpha: .10), borderRadius: BorderRadius.circular(13)), child: Icon(factor.$4, color: factor.$3, size: 16)),
                const SizedBox(width: 11),
                Expanded(
                  child: Column(children: [
                    Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                      Text(factor.$1, style: const TextStyle(color: Color(0xFF4B3C49), fontSize: 12, fontWeight: FontWeight.w700)),
                      Text('${factor.$2}%', style: const TextStyle(color: muted, fontSize: 11, fontWeight: FontWeight.w800)),
                    ]),
                    const SizedBox(height: 2),
                    Align(alignment: Alignment.centerLeft, child: Text(factor.$5, style: const TextStyle(color: Color(0xFFA2949E), fontSize: 10))),
                    const SizedBox(height: 6),
                    ClipRRect(borderRadius: BorderRadius.circular(3), child: LinearProgressIndicator(value: (factor.$2 / 100).clamp(0.0, 1.0), backgroundColor: const Color(0xFFF4EBED), color: factor.$3, minHeight: 5)),
                  ]),
                ),
              ]),
            );
          }).toList(),
        ),
      ),
      if (snapshot.sosActivations > 0) ...[
        SoftCard(
          color: const Color(0xFFFFE3E8),
          child: Row(children: [
            const SoftIcon(icon: Icons.sos_rounded, color: sosRed),
            const SizedBox(width: 11),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text('SOS activations', style: TextStyle(color: plum, fontSize: 13, fontWeight: FontWeight.w800)),
                const SizedBox(height: 3),
                Text('Triggered ${snapshot.sosActivations} time${snapshot.sosActivations == 1 ? '' : 's'} so far', style: const TextStyle(color: Color(0xFF7A4A52), fontSize: 11)),
              ]),
            ),
          ]),
        ),
      ],
      GestureDetector(
        onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const SafeHavensScreen())),
        child: SoftCard(
          color: greenSoft,
          child: Row(children: [
            const SoftIcon(icon: Icons.location_on_outlined, color: green),
            const SizedBox(width: 11),
            const Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('Safety havens near you', style: TextStyle(color: green, fontSize: 13, fontWeight: FontWeight.w800)),
                SizedBox(height: 3),
                Text('Police, hospitals & pharmacies pinned live from OpenStreetMap', style: TextStyle(color: Color(0xFF5D8C7B), fontSize: 10)),
              ]),
            ),
            const Icon(Icons.chevron_right, color: muted),
          ]),
        ),
      ),
    ]);
  }
}