import 'dart:io';

import 'package:flutter/services.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:url_launcher/url_launcher.dart';

/// Places emergency and safety-contact calls straight from SafeHer instead
/// of handing off to the phone app.
///
/// On Android, with CALL_PHONE permission granted, this calls through a
/// native channel that places the call directly (ACTION_CALL), so the
/// person never leaves SafeHer or has to tap "dial" in a separate app — the
/// call simply starts. If permission is declined, or the native call fails,
/// it falls back to opening the dialer prefilled (ACTION_DIAL) so the call
/// is never blocked outright.
///
/// iOS has no public API that starts a phone call without leaving the app —
/// Apple only allows the standard `tel:` handoff, for the same privacy
/// reasons it restricts silent SMS (see SmsService). On iOS, SafeHer is
/// upfront about that instead of pretending otherwise.
class EmergencyService {
  static const _channel = MethodChannel('safeher/call');

  static Future<CallResult> call(String number) async {
    final digits = number.trim();
    if (digits.isEmpty) return CallResult.failed;

    if (Platform.isAndroid) {
      final status = await Permission.phone.request();
      if (status.isGranted) {
        try {
          final placed = await _channel.invokeMethod<bool>('placeCall', {'number': digits});
          if (placed == true) return CallResult.calledDirectly;
        } catch (_) {
          // Fall through to the dialer fallback below.
        }
      }
    }

    final opened = await _openDialer(digits);
    return opened ? CallResult.openedDialer : CallResult.failed;
  }

  /// Back-compat shim for call sites that only need a yes/no result.
  static Future<bool> dial(String number) async {
    final result = await call(number);
    return result != CallResult.failed;
  }

  static Future<bool> _openDialer(String digits) async {
    final uri = Uri(scheme: 'tel', path: digits);
    try {
      return await launchUrl(uri, mode: LaunchMode.externalApplication);
    } catch (_) {
      return false;
    }
  }
}

enum CallResult {
  /// Android only: the call was placed directly from SafeHer, no dialer UI.
  calledDirectly,

  /// The device's dialer opened, prefilled, and needs a tap to place it —
  /// used on iOS always, and on Android when CALL_PHONE isn't granted.
  openedDialer,

  failed,
}

/// A quick-dial emergency number shown on the Home tab and in the chatbot.
class EmergencyNumber {
  const EmergencyNumber(this.label, this.number);

  final String label;
  final String number;
}

const List<EmergencyNumber> indiaEmergencyNumbers = [
  EmergencyNumber('All-in-one (112)', '112'),
  EmergencyNumber('Police (100)', '100'),
  EmergencyNumber('Fire (101)', '101'),
  EmergencyNumber('Ambulance (108)', '108'),
  EmergencyNumber('Women helpline (1091)', '1091'),
];
