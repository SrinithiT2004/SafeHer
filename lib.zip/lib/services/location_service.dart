import 'package:geolocator/geolocator.dart';

/// Result of a permission check, so callers can show the right message
/// instead of a generic error.
enum LocationPermissionResult { granted, serviceDisabled, denied, deniedForever }

class LocationService {
  /// Checks (and if needed requests) location permission. Never throws —
  /// callers get a clear enum instead of an exception, which is what was
  /// causing raw error text to appear on screen before.
  static Future<LocationPermissionResult> ensurePermission() async {
    final serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) return LocationPermissionResult.serviceDisabled;

    var permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
    }

    if (permission == LocationPermission.denied) return LocationPermissionResult.denied;
    if (permission == LocationPermission.deniedForever) return LocationPermissionResult.deniedForever;
    return LocationPermissionResult.granted;
  }

  static Future<Position?> currentPosition({LocationAccuracy accuracy = LocationAccuracy.high}) async {
    final result = await ensurePermission();
    if (result != LocationPermissionResult.granted) return null;
    try {
      return await Geolocator.getCurrentPosition(
        locationSettings: LocationSettings(accuracy: accuracy),
      );
    } catch (_) {
      return null;
    }
  }

  static String messageFor(LocationPermissionResult result) {
    switch (result) {
      case LocationPermissionResult.serviceDisabled:
        return 'Please turn on Location/GPS on your phone and try again.';
      case LocationPermissionResult.denied:
      case LocationPermissionResult.deniedForever:
        return 'SafeHer needs your location to activate SOS and plan safer paths. Please allow location access in Settings.';
      case LocationPermissionResult.granted:
        return '';
    }
  }
}
