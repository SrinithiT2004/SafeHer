import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// One completed trip, recorded the moment the user finishes in-app
/// guidance on a real route (see SafePathsTab). This is the only source of
/// truth the Insights tab and the Home tab's "safety snapshot" draw from —
/// nothing on those screens is hardcoded once at least one trip exists.
class TripRecord {
  const TripRecord({
    required this.source,
    required this.destination,
    required this.safetyScore,
    required this.havenCount,
    required this.durationLabel,
    required this.completedAt,
  });

  final String source;
  final String destination;
  final int safetyScore;
  final int havenCount;
  final String durationLabel;
  final DateTime completedAt;

  Map<String, dynamic> toJson() => {
        'source': source,
        'destination': destination,
        'safetyScore': safetyScore,
        'havenCount': havenCount,
        'durationLabel': durationLabel,
        'completedAt': completedAt.toIso8601String(),
      };

  factory TripRecord.fromJson(Map<String, dynamic> json) => TripRecord(
        source: json['source'] as String? ?? '',
        destination: json['destination'] as String? ?? '',
        safetyScore: (json['safetyScore'] as num?)?.toInt() ?? 0,
        havenCount: (json['havenCount'] as num?)?.toInt() ?? 0,
        durationLabel: json['durationLabel'] as String? ?? '',
        completedAt: DateTime.tryParse(json['completedAt'] as String? ?? '') ?? DateTime.now(),
      );
}

/// Everything the Home tab and Insights tab need to render themselves from
/// real, user-specific data. [hasData] gates the "no trips yet" empty state.
class SafetySnapshot {
  const SafetySnapshot({
    required this.weekly,
    required this.overallScore,
    required this.trendPercent,
    required this.tripCount,
    required this.sosActivations,
    required this.havenFactor,
    required this.contactsFactor,
    required this.goodRouteFactor,
    required this.lastTrip,
  });

  /// 7 values, oldest to today. Days with no completed trip carry the
  /// nearest known score forward so the chart reads as a trend.
  final List<int> weekly;

  final int overallScore;

  /// null until there's a full previous week to compare against.
  final double? trendPercent;

  final int tripCount;
  final int sosActivations;

  /// Derived from real havens found near completed routes.
  final int havenFactor;

  /// Derived from how many trusted contacts actually have a phone number.
  final int contactsFactor;

  /// Share of completed trips on a route SafeHer scored 80+.
  final int goodRouteFactor;

  final TripRecord? lastTrip;

  bool get hasData => tripCount > 0;

  static const empty = SafetySnapshot(
    weekly: [0, 0, 0, 0, 0, 0, 0],
    overallScore: 0,
    trendPercent: null,
    tripCount: 0,
    sosActivations: 0,
    havenFactor: 0,
    contactsFactor: 0,
    goodRouteFactor: 0,
    lastTrip: null,
  );
}

class SafetyStatsService {
  static const _tripsKey = 'trip_history';
  static const _sosCountKey = 'sos_activation_count';
  static const _maxStoredTrips = 60;

  /// Bumped on every recorded trip or SOS activation. The Home tab and
  /// Insights tab listen to this so a trip finished on the Safe paths tab
  /// (or an SOS sent from anywhere) shows up immediately, even though the
  /// bottom nav keeps every tab's State alive via IndexedStack.
  static final ValueNotifier<int> revision = ValueNotifier<int>(0);

  /// Called once in-app guidance finishes for a real route, from
  /// SafePathsTab.
  static Future<void> recordTripCompleted({
    required String source,
    required String destination,
    required int safetyScore,
    required int havenCount,
    required String durationLabel,
  }) async {
    final prefs = await SharedPreferences.getInstance();
    final trips = _decodeTrips(prefs.getStringList(_tripsKey) ?? const []);
    trips.add(TripRecord(
      source: source,
      destination: destination,
      safetyScore: safetyScore,
      havenCount: havenCount,
      durationLabel: durationLabel,
      completedAt: DateTime.now(),
    ));
    trips.sort((a, b) => a.completedAt.compareTo(b.completedAt));
    final trimmed = trips.length > _maxStoredTrips ? trips.sublist(trips.length - _maxStoredTrips) : trips;
    await prefs.setStringList(_tripsKey, trimmed.map((t) => jsonEncode(t.toJson())).toList());
    revision.value++;
  }

  /// Called once an SOS activation actually sends, from SosController.
  static Future<void> recordSosActivation() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt(_sosCountKey, (prefs.getInt(_sosCountKey) ?? 0) + 1);
    revision.value++;
  }

  static List<TripRecord> _decodeTrips(List<String> raw) {
    final trips = <TripRecord>[];
    for (final item in raw) {
      try {
        trips.add(TripRecord.fromJson(jsonDecode(item) as Map<String, dynamic>));
      } catch (_) {
        // Skip anything that fails to parse rather than losing the rest.
      }
    }
    trips.sort((a, b) => a.completedAt.compareTo(b.completedAt));
    return trips;
  }

  static Future<List<TripRecord>> loadTrips() async {
    final prefs = await SharedPreferences.getInstance();
    return _decodeTrips(prefs.getStringList(_tripsKey) ?? const []);
  }

  /// Builds the live snapshot used by both the Home tab card and the
  /// Insights tab, purely from what this user has actually done in the app.
  static Future<SafetySnapshot> loadSnapshot() async {
    final prefs = await SharedPreferences.getInstance();
    final trips = _decodeTrips(prefs.getStringList(_tripsKey) ?? const []);
    final contacts = prefs.getStringList('contacts') ?? const <String>[];
    final sosCount = prefs.getInt(_sosCountKey) ?? 0;

    if (trips.isEmpty) {
      final contactsFactor = contacts.isEmpty ? 0 : _contactsReadyFactor(contacts);
      return SafetySnapshot(
        weekly: const [0, 0, 0, 0, 0, 0, 0],
        overallScore: 0,
        trendPercent: null,
        tripCount: 0,
        sosActivations: sosCount,
        havenFactor: 0,
        contactsFactor: contactsFactor,
        goodRouteFactor: 0,
        lastTrip: null,
      );
    }

    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);

    final weekly = <int>[];
    for (var i = 6; i >= 0; i--) {
      final day = today.subtract(Duration(days: i));
      final dayTrips = trips.where((t) {
        final d = t.completedAt;
        return d.year == day.year && d.month == day.month && d.day == day.day;
      }).toList();
      if (dayTrips.isEmpty) {
        weekly.add(0);
      } else {
        final avg = dayTrips.map((t) => t.safetyScore).reduce((a, b) => a + b) / dayTrips.length;
        weekly.add(avg.round());
      }
    }
    // Carry the nearest known day's score into empty gaps so the trend line
    // stays readable instead of dropping to zero on days with no trip.
    int lastKnown = weekly.firstWhere((v) => v != 0, orElse: () => trips.last.safetyScore);
    for (var i = 0; i < weekly.length; i++) {
      if (weekly[i] == 0) {
        weekly[i] = lastKnown;
      } else {
        lastKnown = weekly[i];
      }
    }

    final overallScore = (weekly.reduce((a, b) => a + b) / weekly.length).round();

    final thisWeek = trips.where((t) => t.completedAt.isAfter(today.subtract(const Duration(days: 7)))).toList();
    final lastWeek = trips
        .where((t) =>
            t.completedAt.isAfter(today.subtract(const Duration(days: 14))) &&
            t.completedAt.isBefore(today.subtract(const Duration(days: 7))))
        .toList();
    double? trendPercent;
    if (thisWeek.isNotEmpty && lastWeek.isNotEmpty) {
      final thisAvg = thisWeek.map((t) => t.safetyScore).reduce((a, b) => a + b) / thisWeek.length;
      final lastAvg = lastWeek.map((t) => t.safetyScore).reduce((a, b) => a + b) / lastWeek.length;
      if (lastAvg > 0) trendPercent = ((thisAvg - lastAvg) / lastAvg) * 100;
    }

    final havenAvg = trips.map((t) => t.havenCount).reduce((a, b) => a + b) / trips.length;
    final havenFactor = (havenAvg * 25).clamp(0, 100).round(); // ~4 havens/trip -> 100%

    final goodRouteTrips = trips.where((t) => t.safetyScore >= 80).length;
    final goodRouteFactor = ((goodRouteTrips / trips.length) * 100).round();

    return SafetySnapshot(
      weekly: weekly,
      overallScore: overallScore,
      trendPercent: trendPercent,
      tripCount: trips.length,
      sosActivations: sosCount,
      havenFactor: havenFactor,
      contactsFactor: _contactsReadyFactor(contacts),
      goodRouteFactor: goodRouteFactor,
      lastTrip: trips.last,
    );
  }

  static int _contactsReadyFactor(List<String> contacts) {
    if (contacts.isEmpty) return 0;
    final withPhones = contacts.where((c) {
      final parts = c.split('|');
      return parts.length > 1 && parts[1].trim().isNotEmpty;
    }).length;
    return ((withPhones / contacts.length) * 100).round();
  }
}
