import 'dart:convert';
import 'dart:math' as math;

//import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:latlong2/latlong.dart';

import '../models.dart';
import '../theme.dart';

class RoutingException implements Exception {
  RoutingException(this.message);
  final String message;
  @override
  String toString() => message;
}

/// Generates real, routable "safest path" options entirely from free
/// OpenStreetMap services — no API key required:
///  - Nominatim for turning a typed place name into coordinates
///  - OSRM for turning two coordinates into an actual walkable path
///  - Overpass for finding nearby police stations / hospitals ("havens")
///
/// Everything here runs live, in the app, from whatever the user just typed
/// or from their current GPS fix — nothing is precomputed or hard-coded.
class RoutingService {
  static const _userAgent = 'SafeHerApp/1.0 (safety navigation app)';
  static const _routeColors = [green, coral, gold];

  static Future<LatLng> geocode(String query) async {
    final uri = Uri.https('nominatim.openstreetmap.org', '/search', {
      'q': query,
      'format': 'json',
      'limit': '1',
    });
    final response = await http.get(uri, headers: {'User-Agent': _userAgent}).timeout(const Duration(seconds: 12));
    if (response.statusCode != 200) {
      throw RoutingException('Could not look up "$query". Check your connection and try again.');
    }
    final results = jsonDecode(response.body) as List;
    if (results.isEmpty) {
      throw RoutingException('Could not find "$query". Try a more specific place name.');
    }
    final first = results.first as Map<String, dynamic>;
    return LatLng(double.parse(first['lat'] as String), double.parse(first['lon'] as String));
  }

  /// Fetches 1-3 real walking routes between [from] and [to], each with an
  /// actual polyline, live turn-by-turn directions, and nearby havens.
  static Future<List<SafeRoute>> fetchRoutes({
    required LatLng from,
    required LatLng to,
    required String fromLabel,
    required String toLabel,
  }) async {
    final uri = Uri.parse(
      'https://router.project-osrm.org/route/v1/foot/'
      '${from.longitude},${from.latitude};${to.longitude},${to.latitude}'
      '?overview=full&geometries=geojson&steps=true&alternatives=true',
    );

    final response = await http.get(uri).timeout(const Duration(seconds: 15));
    if (response.statusCode != 200) {
      throw RoutingException('The routing service is unavailable right now. Please try again shortly.');
    }
    final data = jsonDecode(response.body) as Map<String, dynamic>;
    if (data['code'] != 'Ok' || (data['routes'] as List).isEmpty) {
      throw RoutingException('No walkable route was found between those two points.');
    }

    final rawRoutes = (data['routes'] as List).cast<Map<String, dynamic>>();
    // OSRM alternatives are all reasonable paths; without a live crime/lighting
    // feed we can't claim a true "safety" measurement, so havens found nearby
    // are real, but the score is an honest, clearly-labelled heuristic based
    // on path directness and haven coverage rather than an invented number.
    final havenBox = _boundingBox([from, to, ...rawRoutes.expand((r) => _extractPoints(r))]);
    final havens = await _fetchHavens(havenBox);

    final routes = <SafeRoute>[];
    for (var i = 0; i < rawRoutes.length && i < 3; i++) {
      final raw = rawRoutes[i];
      final points = _extractPoints(raw);
      final nearbyHavens = _havensNearPath(havens, points, maxMeters: 180);
      final distance = (raw['distance'] as num).toDouble();
      final duration = (raw['duration'] as num).toDouble();
      final steps = _buildSteps(raw, fromLabel, toLabel);
      final score = _heuristicScore(distanceMeters: distance, havenCount: nearbyHavens.length, isPrimary: i == 0);

      routes.add(SafeRoute(
        id: 'route_$i',
        name: i == 0 ? 'Recommended route' : 'Alternate route ${String.fromCharCode(65 + i - 1)}',
        subtitle: i == 0 ? 'Best balance of directness & havens nearby' : 'Alternative path',
        distanceMeters: distance,
        durationSeconds: duration,
        safetyScore: score,
        havens: nearbyHavens,
        color: _routeColors[i % _routeColors.length],
        points: points,
        steps: steps,
      ));
    }

    // Sort so the highest heuristic score leads, matching the "safest first" promise.
    routes.sort((a, b) => b.safetyScore.compareTo(a.safetyScore));
    return routes;
  }

  /// Fetches real safety havens (police, hospital, pharmacy) within
  /// [radiusMeters] of [center] — independent of any route. Used by the
  /// standalone Safe Havens screen and by the chatbot's "safe havens" reply.
  static Future<List<Haven>> fetchNearbyHavens(LatLng center, {double radiusMeters = 1500}) {
    return _fetchHavens(_boxAroundPoint(center, radiusMeters));
  }

  /// Like [fetchNearbyHavens], but not pinned to one fixed radius: starts at
  /// [startRadiusMeters] and keeps doubling the search radius — up to
  /// [maxRadiusMeters] — until at least [minResults] havens are found (or
  /// the max radius is hit). Sparse, rural, or low-OSM-coverage areas still
  /// get a useful answer instead of "nothing within 1.5 km".
  static Future<HavensSearchResult> fetchNearbyHavensAdaptive(
    LatLng center, {
    double startRadiusMeters = 1000,
    double maxRadiusMeters = 8000,
    int minResults = 5,
  }) async {
    double radius = startRadiusMeters;
    List<Haven> found = const [];

    while (true) {
      found = await fetchNearbyHavens(center, radiusMeters: radius);
      if (found.length >= minResults || radius >= maxRadiusMeters) break;
      radius = math.min(radius * 2, maxRadiusMeters);
    }

    return HavensSearchResult(havens: found, radiusMeters: radius);
  }

  static _BBox _boxAroundPoint(LatLng center, double radiusMeters) {
    // ~111,320 m per degree of latitude; longitude degrees shrink with cos(lat).
    final dLat = radiusMeters / 111320;
    final dLon = radiusMeters / (111320 * math.cos(center.latitude * math.pi / 180)).abs();
    return _BBox(
      north: center.latitude + dLat,
      south: center.latitude - dLat,
      east: center.longitude + dLon,
      west: center.longitude - dLon,
    );
  }

  static List<LatLng> _extractPoints(Map<String, dynamic> raw) {
    final coords = (raw['geometry']['coordinates'] as List).cast<List>();
    return coords.map((c) => LatLng((c[1] as num).toDouble(), (c[0] as num).toDouble())).toList();
  }

  static List<String> _buildSteps(Map<String, dynamic> raw, String fromLabel, String toLabel) {
    final legs = (raw['legs'] as List).cast<Map<String, dynamic>>();
    final steps = <String>[];
    for (final leg in legs) {
      final legSteps = (leg['steps'] as List).cast<Map<String, dynamic>>();
      for (final step in legSteps) {
        final maneuver = step['maneuver'] as Map<String, dynamic>;
        final type = maneuver['type'] as String? ?? '';
        final modifier = maneuver['modifier'] as String?;
        final roadName = (step['name'] as String?)?.trim() ?? '';
        final distance = (step['distance'] as num?)?.toDouble() ?? 0;
        steps.add(_describeStep(type, modifier, roadName, distance, fromLabel, toLabel));
      }
    }
    if (steps.isEmpty) steps.add('Head toward $toLabel');
    return steps;
  }

  static String _describeStep(String type, String? modifier, String roadName, double distance, String fromLabel, String toLabel) {
    final road = roadName.isEmpty ? 'the path ahead' : roadName;
    final distText = distance >= 15 ? ' for ${distance.round()} m' : '';
    switch (type) {
      case 'depart':
        return 'Head out from $fromLabel onto $road$distText';
      case 'arrive':
        return 'Arrive at $toLabel';
      case 'turn':
        return 'Turn ${modifier ?? ''} onto $road$distText'.replaceAll('  ', ' ');
      case 'new name':
        return 'Continue onto $road$distText';
      case 'roundabout':
      case 'rotary':
        return 'At the roundabout, take the exit onto $road';
      case 'merge':
        return 'Merge onto $road$distText';
      case 'fork':
        return 'At the fork, keep ${modifier ?? 'straight'} onto $road$distText';
      default:
        return 'Continue ${modifier ?? 'straight'} on $road$distText'.replaceAll('  ', ' ');
    }
  }

  static Future<List<Haven>> _fetchHavens(_BBox box) async {
    final query = '''
[out:json][timeout:15];
(
  node["amenity"="police"](${box.south},${box.west},${box.north},${box.east});
  node["amenity"="hospital"](${box.south},${box.west},${box.north},${box.east});
  node["amenity"="pharmacy"](${box.south},${box.west},${box.north},${box.east});
);
out center 40;
''';
    try {
      final response = await http
          .post(
            Uri.parse('https://overpass-api.de/api/interpreter'),
            headers: {'User-Agent': _userAgent},
            body: {'data': query},
          )
          .timeout(const Duration(seconds: 12));
      if (response.statusCode != 200) return const [];
      final data = jsonDecode(response.body) as Map<String, dynamic>;
      final elements = (data['elements'] as List?)?.cast<Map<String, dynamic>>() ?? const [];
      return elements.map((e) {
        final tags = (e['tags'] as Map<String, dynamic>?) ?? const {};
        final amenity = tags['amenity'] as String? ?? 'community';
        final type = amenity == 'police' ? 'police' : (amenity == 'hospital' ? 'hospital' : 'community');
        final name = (tags['name'] as String?) ?? (type == 'police' ? 'Police post' : type == 'hospital' ? 'Hospital' : 'Pharmacy');
        return Haven(name: name, type: type, point: LatLng((e['lat'] as num).toDouble(), (e['lon'] as num).toDouble()));
      }).toList();
    } catch (_) {
      // Havens are a bonus signal — if Overpass is unreachable we still
      // return a real route, just without haven markers.
      return const [];
    }
  }

  static List<Haven> _havensNearPath(List<Haven> havens, List<LatLng> path, {required double maxMeters}) {
    if (path.isEmpty) return const [];
    const distance = Distance();
    final found = <Haven>[];
    for (final haven in havens) {
      var minDist = double.infinity;
      for (final point in path) {
        final d = distance(haven.point, point);
        if (d < minDist) minDist = d;
        if (minDist <= maxMeters) break;
      }
      if (minDist <= maxMeters) found.add(haven);
    }
    return found;
  }

  static int _heuristicScore({required double distanceMeters, required int havenCount, required bool isPrimary}) {
    // Transparent, explainable heuristic (not a measured safety score):
    // shorter/more direct paths and more nearby havens score higher.
    // Base 60, up to +25 for havens, up to +10 for being the primary OSRM route.
    final havenBonus = math.min(25, havenCount * 6);
    final primaryBonus = isPrimary ? 10 : 0;
    final score = 60 + havenBonus + primaryBonus;
    return score.clamp(50, 98);
  }

  static _BBox _boundingBox(List<LatLng> points) {
    var north = -90.0, south = 90.0, east = -180.0, west = 180.0;
    for (final p in points) {
      if (p.latitude > north) north = p.latitude;
      if (p.latitude < south) south = p.latitude;
      if (p.longitude > east) east = p.longitude;
      if (p.longitude < west) west = p.longitude;
    }
    // Pad slightly so havens just off the route are still included.
    const pad = 0.004;
    return _BBox(north: north + pad, south: south - pad, east: east + pad, west: west - pad);
  }
}

/// Result of an adaptive haven search: what was found, and how far out the
/// search actually had to expand to find it.
class HavensSearchResult {
  const HavensSearchResult({required this.havens, required this.radiusMeters});

  final List<Haven> havens;
  final double radiusMeters;

  String get radiusLabel => radiusMeters >= 1000 ? '${(radiusMeters / 1000).toStringAsFixed(radiusMeters % 1000 == 0 ? 0 : 1)} km' : '${radiusMeters.round()} m';
}

class _BBox {
  const _BBox({required this.north, required this.south, required this.east, required this.west});
  final double north, south, east, west;
}
