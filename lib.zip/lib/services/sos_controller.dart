import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:geolocator/geolocator.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'location_service.dart';
import 'safety_stats_service.dart';
import 'sms_service.dart';

enum SosStartFailure { permission, gps, alreadyStarting }

/// Outcome of a call to [SosController.activate].
class SosStartResult {
  const SosStartResult.ok(SosSendResult this.sendResult)
      : failure = null,
        failureMessage = null;

  const SosStartResult.failed(SosStartFailure this.failure, String this.failureMessage) : sendResult = null;

  final SosSendResult? sendResult;
  final SosStartFailure? failure;
  final String? failureMessage;

  bool get isOk => sendResult != null;
}

/// Single source of truth for "is SOS active right now, and where". Both the
/// Home tab's SOS button and the chatbot's "send sos" command go through
/// this controller, so activating from one place is reflected everywhere,
/// and contacts only ever get one stream of live-location texts.
class SosController extends ChangeNotifier {
  SosController._();
  static final SosController instance = SosController._();

  bool active = false;
  bool busy = false;
  Position? currentPosition;
  List<String> lastSentTo = const [];

  StreamSubscription<Position>? _subscription;

  // Live-location SMS throttle. The GPS stream can fire many times per second
  // (and fires once immediately on subscribe), so without this every fix
  // becomes a text. An update is only texted if enough time has passed AND
  // the person has actually moved.
  static const _minSmsInterval = Duration(seconds: 30);
  static const _minSmsDistanceMeters = 25.0;
  Position? _lastSmsPosition;
  DateTime? _lastSmsAt;

  bool _shouldSendUpdate(Position updated) {
    final lastPos = _lastSmsPosition;
    final lastAt = _lastSmsAt;
    if (lastPos == null || lastAt == null) return true;
    if (DateTime.now().difference(lastAt) < _minSmsInterval) return false;
    final moved = Geolocator.distanceBetween(
      lastPos.latitude,
      lastPos.longitude,
      updated.latitude,
      updated.longitude,
    );
    return moved >= _minSmsDistanceMeters;
  }

  Future<List<String>> loadContactPhones() async {
    final prefs = await SharedPreferences.getInstance();
    final contacts = prefs.getStringList('contacts') ?? <String>[];
    final phones = <String>[];
    for (final contact in contacts) {
      final parts = contact.split('|');
      if (parts.length > 1 && parts[1].trim().isNotEmpty) {
        phones.add(parts[1].trim());
      }
    }
    return phones;
  }

  /// How many saved trusted contacts have NO phone number on file, so
  /// callers can explain why fewer people were texted than the total
  /// contact count shown on the Profile tab.
  Future<int> countContactsWithoutPhone() async {
    final prefs = await SharedPreferences.getInstance();
    final contacts = prefs.getStringList('contacts') ?? <String>[];
    var missing = 0;
    for (final contact in contacts) {
      final parts = contact.split('|');
      final phone = parts.length > 1 ? parts[1].trim() : '';
      if (phone.isEmpty) missing++;
    }
    return missing;
  }

  /// Name|phone pairs for contacts that actually have a phone number, for
  /// callers (like the chatbot) that want to show names, not just numbers.
  Future<List<(String name, String phone)>> loadContacts() async {
    final prefs = await SharedPreferences.getInstance();
    final contacts = prefs.getStringList('contacts') ?? <String>[];
    final result = <(String, String)>[];
    for (final contact in contacts) {
      final parts = contact.split('|');
      final name = parts.isNotEmpty ? parts[0].trim() : '';
      final phone = parts.length > 1 ? parts[1].trim() : '';
      if (phone.isNotEmpty) result.add((name.isEmpty ? phone : name, phone));
    }
    return result;
  }

  String sosMessage(Position position) {
    final lat = position.latitude.toStringAsFixed(6);
    final lon = position.longitude.toStringAsFixed(6);
    final mapLink = 'https://www.openstreetmap.org/?mlat=$lat&mlon=$lon#map=18/$lat/$lon';
    return 'SAFEHER SOS: I need help. My live location is $mapLink';
  }

  /// Turns SOS on: gets a GPS fix, sends the live-location message to every
  /// trusted contact right away, then keeps sending updates as the position
  /// changes until [stop] is called.
  Future<SosStartResult> activate() async {
    if (active) {
      // Already running elsewhere (e.g. started from the Home tab) — report
      // success without re-sending, so a second "send sos" doesn't spam.
      return SosStartResult.ok(SosSendResult(SosSendOutcome.sentDirectly, sent: lastSentTo));
    }
    if (busy) {
      return const SosStartResult.failed(SosStartFailure.alreadyStarting, 'SOS is already starting.');
    }

    busy = true;
    notifyListeners();

    try {
      final permission = await LocationService.ensurePermission();
      if (permission != LocationPermissionResult.granted) {
        return SosStartResult.failed(SosStartFailure.permission, LocationService.messageFor(permission));
      }

      final position = await Geolocator.getCurrentPosition(
        locationSettings: const LocationSettings(accuracy: LocationAccuracy.bestForNavigation),
      );

      // De-duplicate so the same number saved twice isn't texted twice.
      final phones = (await loadContactPhones()).toSet().toList();

      // The initial message below counts as the first send. Recording it
      // before subscribing stops the stream's immediate first fix from
      // triggering a duplicate.
      _lastSmsPosition = position;
      _lastSmsAt = DateTime.now();

      active = true;
      currentPosition = position;
      notifyListeners();

      await _subscription?.cancel();
      _subscription = Geolocator.getPositionStream(
        locationSettings: const LocationSettings(accuracy: LocationAccuracy.bestForNavigation, distanceFilter: 5),
      ).listen((updated) {
        currentPosition = updated;
        notifyListeners();
        if (phones.isNotEmpty && _shouldSendUpdate(updated)) {
          _lastSmsPosition = updated;
          _lastSmsAt = DateTime.now();
          SmsService.sendSos(phoneNumbers: phones, message: sosMessage(updated));
        }
      });

      final result = await SmsService.sendSos(phoneNumbers: phones, message: sosMessage(position));
      lastSentTo = result.sent;
      SafetyStatsService.recordSosActivation();
      return SosStartResult.ok(result);
    } catch (_) {
      return const SosStartResult.failed(
        SosStartFailure.gps,
        'GPS could not provide a current position. Please check Location and try again.',
      );
    } finally {
      busy = false;
      notifyListeners();
    }
  }

  Future<void> stop() async {
    await _subscription?.cancel();
    _subscription = null;
    _lastSmsPosition = null;
    _lastSmsAt = null;
    active = false;
    lastSentTo = const [];
    notifyListeners();
  }

  @override
  void dispose() {
    _subscription?.cancel();
    super.dispose();
  }
}
