import 'dart:io';

import 'package:flutter/services.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:url_launcher/url_launcher.dart';

enum SosSendOutcome {
  sentDirectly, // Android: SMS left the phone with no extra tap.
  openedComposer, // Fallback: messaging app opened, prefilled, user must tap Send.
  noContacts,
  failed,
}

class SosSendResult {
  const SosSendResult(this.outcome, {this.sent = const [], this.failed = const []});

  final SosSendOutcome outcome;
  final List<String> sent;
  final List<String> failed;
}

class SmsService {
  static const _channel = MethodChannel('safeher/sms');

  /// Sends [message] to every number in [phoneNumbers].
  ///
  /// On Android this sends the SMS directly through the device's SmsManager
  /// with no messaging app UI involved, once SEND_SMS permission is granted.
  /// iOS has no public API for a silent send — Apple only allows a
  /// user-facing compose sheet (MFMessageComposeViewController) for privacy
  /// reasons, so on iOS (and if the user declines the SMS permission on
  /// Android) SafeHer falls back to opening the messaging app prefilled with
  /// the live location, and is upfront with the user about why.
  static Future<SosSendResult> sendSos({
    required List<String> phoneNumbers,
    required String message,
  }) async {
    if (phoneNumbers.isEmpty) {
      return const SosSendResult(SosSendOutcome.noContacts);
    }

    if (Platform.isAndroid) {
      final status = await Permission.sms.request();
      if (status.isGranted) {
        try {
          final raw = await _channel.invokeMethod<Map<dynamic, dynamic>>('sendSms', {
            'numbers': phoneNumbers,
            'message': message,
          });
          final sent = (raw?['sent'] as List?)?.cast<String>() ?? const [];
          final failed = (raw?['failed'] as List?)?.cast<String>() ?? const [];
          if (sent.isNotEmpty) {
            return SosSendResult(SosSendOutcome.sentDirectly, sent: sent, failed: failed);
          }
        } catch (_) {
          // Fall through to the composer fallback below.
        }
      }
    }

    final opened = await _openComposer(phoneNumbers, message);
    return SosSendResult(opened ? SosSendOutcome.openedComposer : SosSendOutcome.failed);
  }

  /// Opens the messaging app prefilled to send [message] to [number] — used
  /// by the Mobile Complaint form to hand a drafted complaint to the local
  /// control room's SMS line without needing a backend of our own.
  static Future<bool> openComposer(String number, String message) => _openComposer([number], message);

  static Future<bool> _openComposer(List<String> phoneNumbers, String message) async {
    final smsUri = Uri(
      scheme: 'sms',
      path: phoneNumbers.join(','),
      queryParameters: <String, String>{'body': message},
    );
    try {
      return await launchUrl(smsUri, mode: LaunchMode.externalApplication);
    } catch (_) {
      return false;
    }
  }
}
