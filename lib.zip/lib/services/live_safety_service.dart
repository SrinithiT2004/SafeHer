import 'dart:async';
import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:geolocator/geolocator.dart';
import 'package:latlong2/latlong.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../models.dart';
import 'routing_service.dart';
import 'safety_stats_service.dart';

/// A live reading of how safe the user's surroundings look *right now*,
/// recomputed as they move, as time passes, and as their contacts change.
class LiveSafetyState {
  const LiveSafetyState({
    required this.tracking,
    required this.updatedAt,
    required this.havensNearby,
    required this.nearestHavenMeters,
    required this.stationaryMinutes,
    required this.havenFactor,
    required this.contactsFactor,
    required this.timeFactor,
    required this.movementFactor,
    required this.score,
    required this.todayAverage,
    required this.dailyAverages,
  });

  /// True once a real GPS fix has been received.
  final bool tracking;
  final DateTime? updatedAt;

  final int havensNearby;
  final double? nearestHavenMeters;
  final int stationaryMinutes;

  final int havenFactor;
  final int contactsFactor;
  final int timeFactor;
  final int movementFactor;

  /// Live confidence score 0-100, or null until a GPS fix exists.
  final int? score;

  /// Average of today's live samples (null before the first sample).
  final int? todayAverage;

  /// Last 7 days (oldest -> today) of stored live averages; 0 = no data.
  final List<int> dailyAverages;

  static const initial = LiveSafetyState(
    tracking: false,
    updatedAt: null,
    havensNearby: 0,
    nearestHavenMeters: null,
    stationaryMinutes: 0,
    havenFactor: 0,
    contactsFactor: 0,
    timeFactor: 100,
    movementFactor: 100,
    score: null,
    todayAverage: null,
    dailyAverages: [0, 0, 0, 0, 0, 0, 0],
  );
}

/// Watches the phone's GPS and turns it into a continuously updating
/// safety reading for the Insights tab. Starts once from AppShell.
class LiveSafetyService {
  static final ValueNotifier<LiveSafetyState> state = ValueNotifier(LiveSafetyState.initial);

  static const _dailyKey = 'live_daily_scores';
  static const _havenRadius = 1500.0;

  static StreamSubscription<Position>? _positionSub;
  static Timer? _timer;
  static bool _started = false;

  static Position? _position;
  static Position? _anchor;
  static DateTime _anchorTime = DateTime.now();

  static List<Haven> _havens = const [];
  static LatLng? _havenFetchPoint;
  static DateTime? _havenFetchedAt;
  static bool _fetchingHavens = false;

  static int _contactsFactor = 0;
  static Map<String, List<num>> _daily = {}; // 'yyyy-MM-dd' -> [sum, count]
  static DateTime _lastSample = DateTime.fromMillisecondsSinceEpoch(0);

  static Future<void> start() async {
    if (_started) return;
    _started = true;

    await _loadDaily();
    await _loadContacts();
    SafetyStatsService.revision.addListener(_onDataChanged);

    await _ensureTracking();
    // Re-evaluates time-of-day / idle time and retries GPS if it was off.
    _timer = Timer.periodic(const Duration(seconds: 20), (_) async {
      await _ensureTracking();
      _recompute();
    });
    _recompute();
  }

  static void stop() {
    _positionSub?.cancel();
    _timer?.cancel();
    SafetyStatsService.revision.removeListener(_onDataChanged);
    _positionSub = null;
    _timer = null;
    _started = false;
  }

  static Future<void> _onDataChanged() async {
    await _loadContacts();
    _recompute();
  }

  static Future<void> _ensureTracking() async {
    if (_positionSub != null) return;
    try {
      if (!await Geolocator.isLocationServiceEnabled()) return;
      final permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied || permission == LocationPermission.deniedForever) return;

      // Seed with a quick fix so the screen isn't empty while waiting for
      // the first stream update.
      final last = await Geolocator.getLastKnownPosition();
      if (last != null) _onPosition(last);

      _positionSub = Geolocator.getPositionStream(
        locationSettings: const LocationSettings(accuracy: LocationAccuracy.high, distanceFilter: 10),
      ).listen(_onPosition, onError: (_) {
        _positionSub?.cancel();
        _positionSub = null;
      });
    } catch (_) {
      // Try again on the next tick.
    }
  }

  static void _onPosition(Position pos) {
    _position = pos;
    final anchor = _anchor;
    if (anchor == null || Geolocator.distanceBetween(anchor.latitude, anchor.longitude, pos.latitude, pos.longitude) > 30) {
      _anchor = pos;
      _anchorTime = DateTime.now();
    }
    _maybeFetchHavens(pos);
    _recompute();
  }

  static Future<void> _maybeFetchHavens(Position pos) async {
    if (_fetchingHavens) return;
    final here = LatLng(pos.latitude, pos.longitude);
    final movedFar = _havenFetchPoint == null || Geolocator.distanceBetween(_havenFetchPoint!.latitude, _havenFetchPoint!.longitude, here.latitude, here.longitude) > 300;
    final stale = _havenFetchedAt == null || DateTime.now().difference(_havenFetchedAt!) > const Duration(minutes: 5);
    final retryEmpty = _havens.isEmpty && _havenFetchedAt != null && DateTime.now().difference(_havenFetchedAt!) > const Duration(minutes: 2);
    if (!(movedFar || (stale && _havens.isNotEmpty) || retryEmpty)) return;

    _fetchingHavens = true;
    try {
      final found = await RoutingService.fetchNearbyHavens(here, radiusMeters: _havenRadius + 300);
      _havens = found;
      _havenFetchPoint = here;
      _havenFetchedAt = DateTime.now();
    } catch (_) {
      _havenFetchedAt = DateTime.now();
    } finally {
      _fetchingHavens = false;
    }
    _recompute();
  }

  // ---- scoring -------------------------------------------------------

  static int _timeFactor(DateTime now) {
    final h = now.hour;
    if (h >= 7 && h < 18) return 100;
    if (h >= 18 && h < 20) return 80;
    if (h >= 20 && h < 22) return 60;
    if (h >= 22 || h < 4) return 35;
    return 55; // 4-7am
  }

  static void _recompute() {
    final now = DateTime.now();
    final pos = _position;

    final timeFactor = _timeFactor(now);

    if (pos == null) {
      state.value = LiveSafetyState(
        tracking: false,
        updatedAt: now,
        havensNearby: 0,
        nearestHavenMeters: null,
        stationaryMinutes: 0,
        havenFactor: 0,
        contactsFactor: _contactsFactor,
        timeFactor: timeFactor,
        movementFactor: 100,
        score: null,
        todayAverage: _todayAverage(now),
        dailyAverages: _dailyAverages(now),
      );
      return;
    }

    // Havens actually within range of where the user is now.
    var count = 0;
    double? nearest;
    for (final h in _havens) {
      final d = Geolocator.distanceBetween(pos.latitude, pos.longitude, h.point.latitude, h.point.longitude);
      if (d <= _havenRadius) count++;
      if (nearest == null || d < nearest) nearest = d;
    }
    final countPart = (count.clamp(0, 5) / 5 * 70);
    final nearPart = nearest == null
        ? 0
        : nearest <= 300
            ? 30
            : nearest <= 800
                ? 20
                : nearest <= 1500
                    ? 10
                    : 0;
    final havenFactor = (countPart + nearPart).round().clamp(0, 100);

    final idleMinutes = now.difference(_anchorTime).inMinutes;
    final movementFactor = idleMinutes < 2
        ? 100
        : idleMinutes < 10
            ? 85
            : idleMinutes < 30
                ? 65
                : 50;

    final score = (havenFactor * 0.40 + timeFactor * 0.25 + movementFactor * 0.15 + _contactsFactor * 0.20).round().clamp(0, 100);

    // Store at most one sample a minute into today's running average.
    if (now.difference(_lastSample) >= const Duration(minutes: 1)) {
      _lastSample = now;
      _addSample(now, score);
    }

    state.value = LiveSafetyState(
      tracking: true,
      updatedAt: now,
      havensNearby: count,
      nearestHavenMeters: nearest,
      stationaryMinutes: idleMinutes,
      havenFactor: havenFactor,
      contactsFactor: _contactsFactor,
      timeFactor: timeFactor,
      movementFactor: movementFactor,
      score: score,
      todayAverage: _todayAverage(now),
      dailyAverages: _dailyAverages(now),
    );
  }

  // ---- persistence ---------------------------------------------------

  static String _dayKey(DateTime d) => '${d.year.toString().padLeft(4, '0')}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';

  static int? _todayAverage(DateTime now) {
    final e = _daily[_dayKey(now)];
    if (e == null || e[1] == 0) return null;
    return (e[0] / e[1]).round();
  }

  static List<int> _dailyAverages(DateTime now) {
    final today = DateTime(now.year, now.month, now.day);
    return [
      for (var i = 6; i >= 0; i--)
        () {
          final e = _daily[_dayKey(today.subtract(Duration(days: i)))];
          return (e == null || e[1] == 0) ? 0 : (e[0] / e[1]).round();
        }()
    ];
  }

  static Future<void> _addSample(DateTime now, int score) async {
    final key = _dayKey(now);
    final e = _daily[key] ?? [0, 0];
    _daily[key] = [e[0] + score, e[1] + 1];
    // Keep only the last 14 days.
    final keys = _daily.keys.toList()..sort();
    while (keys.length > 14) {
      _daily.remove(keys.removeAt(0));
    }
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(_dailyKey, jsonEncode(_daily));
    } catch (_) {}
  }

  static Future<void> _loadDaily() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final raw = prefs.getString(_dailyKey);
      if (raw == null) return;
      final decoded = jsonDecode(raw) as Map<String, dynamic>;
      _daily = decoded.map((k, v) => MapEntry(k, (v as List).map((e) => e as num).toList()));
    } catch (_) {
      _daily = {};
    }
  }

  static Future<void> _loadContacts() async {
    final prefs = await SharedPreferences.getInstance();
    final contacts = prefs.getStringList('contacts') ?? const <String>[];
    final withPhones = contacts.where((c) {
      final parts = c.split('|');
      return parts.length > 1 && parts[1].trim().isNotEmpty;
    }).length;
    // 1 reachable contact = 50%, 2 or more = 100%.
    _contactsFactor = (withPhones * 50).clamp(0, 100);
  }
}