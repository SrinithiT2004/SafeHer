/// What the user is actually asking for, extracted from free text.
///
/// This is intentionally just parsing — no network calls, no BuildContext.
/// [ChatbotTab] (which owns location, routing, SOS, contacts, and dialing)
/// reads the [ParsedIntent] and does the real work: sending the SOS,
/// fetching a route, looking up havens, dialing a number, or saving a
/// contact. The bot acts, it doesn't just explain which screen to go tap.
enum ChatIntent {
  greeting,
  sos,
  stopSos,
  route,
  havens,
  callEmergency,
  complaint,
  addContact,
  listContacts,
  capabilities,
  thanks,
  unknown,
}

class ParsedIntent {
  const ParsedIntent(
    this.intent, {
    this.destination,
    this.contactName,
    this.contactPhone,
    this.emergencyNumber,
    this.emergencyLabel,
  });

  final ChatIntent intent;
  final String? destination;
  final String? contactName;
  final String? contactPhone;

  /// For [ChatIntent.callEmergency]: which number to dial and a friendly
  /// label for it (e.g. "108" / "Ambulance").
  final String? emergencyNumber;
  final String? emergencyLabel;
}

class ChatbotService {
  static ParsedIntent parse(String input) {
    final text = ' ${input.toLowerCase().trim()} ';

    // Explicit "start" phrasing is checked first and wins outright, so a
    // direct command like "send sos" (the exact text the quick-action
    // button and the help text use) can never be shadowed by a broader
    // stop-phrase match below.
    if (_any(text, ['send sos', 'activate sos', 'start sos', 'trigger sos', 'raise sos'])) {
      return const ParsedIntent(ChatIntent.sos);
    }

    if (_any(text, ['stop sos', 'cancel sos', 'end sos', 'turn off sos', 'stop tracking', 'disable sos', "i'm safe now", 'i am safe now'])) {
      return const ParsedIntent(ChatIntent.stopSos);
    }

    final emergencyCall = _parseEmergencyCall(text);
    if (emergencyCall != null) return emergencyCall;

    if (_any(text, [
      ' sos ',
      'emergency',
      'help me',
      'i am in danger',
      "i'm in danger",
      'i am unsafe',
      "i'm unsafe",
      'i feel unsafe',
      'i feel scared',
      'i am scared',
      "i'm scared",
      'someone is following me',
      'being followed',
      'im being followed',
      'send my location',
      'send help',
      'i need help',
      'i am in trouble',
      "i'm in trouble",
      'not safe here',
      'being harassed',
      'someone is attacking me',
    ])) {
      return const ParsedIntent(ChatIntent.sos);
    }

    if (_any(text, [
      'file a complaint',
      'file complaint',
      'lodge a complaint',
      'lodge complaint',
      'register a complaint',
      'register complaint',
      'mobile complaint',
      'report an incident',
      'report incident',
      'report a crime',
      'i want to complain',
      'i want to report',
    ])) {
      return const ParsedIntent(ChatIntent.complaint);
    }

    final addContactMatch = _addContactPattern.firstMatch(text);
    if (addContactMatch != null) {
      final phone = addContactMatch.group(2)!.trim();
      final rawName = addContactMatch.group(1)!.trim();
      return ParsedIntent(ChatIntent.addContact, contactName: _titleCase(rawName), contactPhone: phone);
    }

    if (_any(text, ['who are my contacts', 'my trusted contacts', 'list my contacts', 'show my contacts', 'my emergency contacts', 'view my contacts'])) {
      return const ParsedIntent(ChatIntent.listContacts);
    }

    final destination = _extractDestination(text);
    if (destination != null) {
      return ParsedIntent(ChatIntent.route, destination: destination);
    }
    if (_any(text, ['route', 'safe path', 'safest way', 'walk home', 'directions', 'navigate', 'navigation'])) {
      return const ParsedIntent(ChatIntent.route);
    }

    if (_any(text, [
      'haven',
      'police station',
      'hospital',
      'pharmacy',
      'chemist',
      'safe place',
      'safe spot',
      'nearest police',
      'nearest hospital',
      'nearest pharmacy',
      'somewhere safe',
      'safe location nearby',
    ])) {
      return const ParsedIntent(ChatIntent.havens);
    }

    if (_any(text, ['what can you do', 'what do you do', 'help ', ' commands', 'how do you work'])) {
      return const ParsedIntent(ChatIntent.capabilities);
    }

    if (_any(text, ['hi ', 'hello', 'hey', 'namaste', 'good morning', 'good evening', 'good afternoon'])) {
      return const ParsedIntent(ChatIntent.greeting);
    }

    if (_any(text, ['thank', 'thanks', 'appreciate it'])) {
      return const ParsedIntent(ChatIntent.thanks);
    }

    return const ParsedIntent(ChatIntent.unknown);
  }

  // "call police", "dial 112", "call ambulance now", "phone the fire brigade"
  static final _emergencyKeywords = <String, (String number, String label)>{
    'ambulance': ('108', 'Ambulance'),
    'fire': ('101', 'Fire'),
    'women helpline': ('1091', 'Women helpline'),
    'police': ('100', 'Police'),
  };

  static ParsedIntent? _parseEmergencyCall(String text) {
    final mentionsCallVerb = _any(text, ['call ', 'dial ']);
    if (!mentionsCallVerb) return null;

    // An explicit number, e.g. "dial 112" / "call 100".
    final numberMatch = RegExp(r'\b(112|100|101|108|1091)\b').firstMatch(text);
    if (numberMatch != null) {
      final number = numberMatch.group(1)!;
      final label = _emergencyKeywords.values.firstWhere((v) => v.$1 == number, orElse: () => ('112', 'Emergency')).$2;
      return ParsedIntent(ChatIntent.callEmergency, emergencyNumber: number, emergencyLabel: label);
    }

    for (final entry in _emergencyKeywords.entries) {
      if (text.contains(entry.key)) {
        return ParsedIntent(ChatIntent.callEmergency, emergencyNumber: entry.value.$1, emergencyLabel: entry.value.$2);
      }
    }

    if (_any(text, ['call emergency', 'dial emergency', 'call for help', 'emergency number', 'call the helpline'])) {
      return const ParsedIntent(ChatIntent.callEmergency, emergencyNumber: '112', emergencyLabel: 'Emergency');
    }

    return null;
  }

  // "route to koramangala", "directions to the metro station",
  // "navigate to indiranagar", "safest way to my office", "take me to X",
  // "how do i get to X", "i want to go to X"
  static final _destinationPattern = RegExp(
    r'\b(?:route|directions?|navigate|navigation|take me|walk|path|way|go|get)\b.*?\bto\s+(.+)$',
  );

  static String? _extractDestination(String text) {
    final match = _destinationPattern.firstMatch(text.trim());
    if (match == null) return null;
    var dest = match.group(1)!.trim();
    dest = dest.replaceAll(RegExp(r'[.?!]+$'), '').trim();
    if (dest.isEmpty) return null;
    return dest;
  }

  // "add contact Mom 9876543210", "add Dad as contact 9123456780",
  // "add emergency contact Priya 9988776655", "save contact Raj 9988112233"
  static final _addContactPattern = RegExp(
    r'\b(?:add|save)\b(?:\s+(?:an?\s+)?(?:emergency|trusted|safety)?\s*contact)?\s+([a-z][a-z .]*?)\s+(?:as\s+(?:a\s+)?(?:contact|emergency contact)\s+)?(\+?\d[\d\s-]{6,}\d)\b',
  );

  static String _titleCase(String value) => value
      .split(RegExp(r'\s+'))
      .where((w) => w.isNotEmpty)
      .map((w) => w[0].toUpperCase() + w.substring(1))
      .join(' ');

  static bool _any(String text, List<String> keywords) => keywords.any(text.contains);
}
