import 'package:flutter/material.dart';
import '../theme.dart';

void showAppDialog(BuildContext context, String title, String message) {
  showDialog<void>(
    context: context,
    builder: (dialogContext) => AlertDialog(
      title: Text(title),
      content: Text(message),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(dialogContext),
          child: const Text('Done'),
        ),
      ],
    ),
  );
}

class AppScroll extends StatelessWidget {
  const AppScroll({super.key, required this.children});

  final List<Widget> children;

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(20, 14, 20, 28),
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: children),
      ),
    );
  }
}

class Header extends StatelessWidget {
  const Header({super.key, required this.eyebrow, required this.title, this.initials, this.icon});

  final String eyebrow;
  final String title;
  final String? initials;
  final IconData? icon;

  @override
  Widget build(BuildContext context) {
    return Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
      Expanded(
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(eyebrow, style: const TextStyle(color: muted, fontSize: 12, fontWeight: FontWeight.w500)),
          const SizedBox(height: 4),
          Text(title, style: const TextStyle(color: ink, fontSize: 27, fontWeight: FontWeight.w700, letterSpacing: -.7)),
        ]),
      ),
      if (initials != null)
        CircleAvatar(radius: 21, backgroundColor: blushStrong, child: Text(initials!, style: const TextStyle(color: plum, fontSize: 12, fontWeight: FontWeight.w800))),
      if (icon != null)
        Container(width: 42, height: 42, decoration: BoxDecoration(color: blush, borderRadius: BorderRadius.circular(15)), child: Icon(icon, color: plum, size: 19)),
    ]);
  }
}

class SectionHeading extends StatelessWidget {
  const SectionHeading({super.key, required this.eyebrow, required this.title, this.action});

  final String eyebrow;
  final String title;
  final Widget? action;

  @override
  Widget build(BuildContext context) {
    return Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, crossAxisAlignment: CrossAxisAlignment.end, children: [
      Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Container(width: 6, height: 6, decoration: const BoxDecoration(color: coral, shape: BoxShape.circle)),
          const SizedBox(width: 5),
          Text(eyebrow, style: const TextStyle(color: plum, fontSize: 10, fontWeight: FontWeight.w800, letterSpacing: 1)),
        ]),
        const SizedBox(height: 6),
        Text(title, style: const TextStyle(color: ink, fontSize: 21, fontWeight: FontWeight.w700)),
      ]),
      if (action != null) action!,
    ]);
  }
}

class SoftCard extends StatelessWidget {
  const SoftCard({super.key, required this.child, this.color = Colors.white});

  final Widget child;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(20), border: color == Colors.white ? Border.all(color: border) : null),
      padding: const EdgeInsets.all(15),
      child: child,
    );
  }
}

class SoftIcon extends StatelessWidget {
  const SoftIcon({super.key, required this.icon, required this.color});

  final IconData icon;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 36,
      height: 36,
      decoration: BoxDecoration(color: color == green ? const Color(0xFFD6F0E5) : blushStrong, borderRadius: BorderRadius.circular(13)),
      child: Icon(icon, color: color, size: 18),
    );
  }
}

class RouteTextField extends StatelessWidget {
  const RouteTextField({super.key, required this.label, required this.controller, required this.markerColor, this.suffix});

  final String label;
  final TextEditingController controller;
  final Color markerColor;
  final Widget? suffix;

  @override
  Widget build(BuildContext context) {
    return Row(children: [
      Container(width: 10, height: 10, decoration: BoxDecoration(color: markerColor, shape: BoxShape.circle, border: Border.all(color: Colors.white, width: 2))),
      const SizedBox(width: 11),
      Expanded(
        child: TextField(
          controller: controller,
          decoration: InputDecoration(
            labelText: label,
            labelStyle: const TextStyle(color: Color(0xFF9B8D97), fontSize: 9, fontWeight: FontWeight.w800, letterSpacing: 1),
            border: InputBorder.none,
            isDense: true,
          ),
          style: const TextStyle(color: ink, fontSize: 14, fontWeight: FontWeight.w600),
        ),
      ),
      if (suffix != null) suffix!,
    ]);
  }
}

class RouteConnector extends StatelessWidget {
  const RouteConnector({super.key});

  @override
  Widget build(BuildContext context) {
    return Row(children: [
      const SizedBox(width: 4),
      Container(width: 1, height: 16, color: const Color(0xFFD9CDD4)),
      const SizedBox(width: 26),
    ]);
  }
}

class MapLabel extends StatelessWidget {
  const MapLabel(this.label, {super.key});

  final String label;

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(6), boxShadow: const [BoxShadow(color: Color(0x14000000), blurRadius: 4)]),
      padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 3),
      child: Text(label, style: const TextStyle(color: plum, fontSize: 9, fontWeight: FontWeight.w700)),
    );
  }
}

class SettingRow extends StatelessWidget {
  const SettingRow({super.key, required this.icon, required this.color, required this.title, required this.subtitle, required this.trailing});

  final IconData icon;
  final Color color;
  final String title;
  final String subtitle;
  final Widget trailing;

  @override
  Widget build(BuildContext context) {
    return Row(children: [
      Container(width: 34, height: 34, decoration: BoxDecoration(color: blush, borderRadius: BorderRadius.circular(12)), child: Icon(icon, color: color, size: 16)),
      const SizedBox(width: 11),
      Expanded(
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(title, style: const TextStyle(color: Color(0xFF4B3C49), fontSize: 12, fontWeight: FontWeight.w800)),
          const SizedBox(height: 3),
          Text(subtitle, style: const TextStyle(color: muted, fontSize: 10)),
        ]),
      ),
      trailing,
    ]);
  }
}

class OnPill extends StatelessWidget {
  const OnPill({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(color: greenSoft, borderRadius: BorderRadius.circular(7)),
      padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 4),
      child: const Text('ON', style: TextStyle(color: green, fontSize: 9, fontWeight: FontWeight.w900)),
    );
  }
}

class MiniBars extends StatelessWidget {
  /// [values] are 0-100 scores; the bar height scales to fit. Defaults to a
  /// static placeholder pattern when no real data is passed.
  const MiniBars({super.key, this.values = const [46, 60, 54, 76, 68, 89, 82, 92, 76, 88, 94, 84, 92, 86, 94, 90]});

  final List<int> values;

  @override
  Widget build(BuildContext context) {
    final bars = values.isEmpty ? const [0] : values;
    final maxValue = bars.reduce((a, b) => a > b ? a : b).clamp(1, 100);
    return Row(
      crossAxisAlignment: CrossAxisAlignment.end,
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: bars
          .asMap()
          .entries
          .map((entry) => Container(
                width: 8,
                height: ((entry.value / maxValue) * 94).clamp(4.0, 94.0),
                decoration: BoxDecoration(
                  color: entry.key == bars.length - 1 ? coral : const Color(0xFFF2C7D1),
                  borderRadius: BorderRadius.circular(5),
                ),
              ))
          .toList(),
    );
  }
}
