import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';

import '../models.dart';
import '../theme.dart';

/// Renders a real OpenStreetMap tile map with, depending on what's
/// available: the computed route polyline, start/end pins, nearby safety
/// havens, and the user's live GPS position — all layered together instead
/// of one silently overriding another.
class RouteMapView extends StatelessWidget {
  const RouteMapView({
    super.key,
    this.route,
    this.liveLatLng,
    this.compact = false,
    this.loading = false,
    this.emptyHint,
    this.havens,
    this.center,
    this.initialZoom,
  });

  final SafeRoute? route;
  final LatLng? liveLatLng;
  final bool compact;
  final bool loading;
  final String? emptyHint;

  /// Havens to pin even when there's no [route] (e.g. the standalone Safe
  /// Havens screen). If [route] is also set, its havens are shown instead.
  final List<Haven>? havens;

  /// Explicit map center to use when there's no route polyline to fit to.
  final LatLng? center;
  final double? initialZoom;

  @override
  Widget build(BuildContext context) {
    final points = route?.points ?? const <LatLng>[];
    final pinnedHavens = route?.havens ?? havens ?? const <Haven>[];
    final center = liveLatLng ?? this.center ?? (points.isNotEmpty ? points[points.length ~/ 2] : const LatLng(12.9716, 77.5946));

    return ClipRRect(
      borderRadius: BorderRadius.circular(compact ? 16 : 20),
      child: Stack(children: [
        FlutterMap(
          options: MapOptions(
            initialCenter: center,
            initialZoom: initialZoom ?? (points.isNotEmpty ? 15 : 14),
            initialCameraFit: points.length > 1
                ? CameraFit.coordinates(
                    coordinates: points,
                    padding: const EdgeInsets.all(36),
                  )
                : null,
            interactionOptions: InteractionOptions(flags: compact ? InteractiveFlag.none : InteractiveFlag.all),
          ),
          children: [
            TileLayer(
              urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
              userAgentPackageName: 'com.safeher.safeher',
            ),
            if (points.length > 1)
              PolylineLayer(polylines: [
                Polyline(points: points, strokeWidth: 6, color: (route?.color ?? coral)),
              ]),
            MarkerLayer(markers: [
              if (points.isNotEmpty) _pin(points.first, plum, Icons.trip_origin),
              if (points.isNotEmpty) _pin(points.last, coral, Icons.flag_rounded),
              for (final haven in pinnedHavens) _havenPin(haven),
              if (liveLatLng != null) _liveDot(liveLatLng!),
            ]),
            const RichAttributionWidget(attributions: [TextSourceAttribution('OpenStreetMap contributors')]),
          ],
        ),
        if (loading)
          const Positioned.fill(
            child: ColoredBox(
              color: Color(0x66FFFFFF),
              child: Center(child: CircularProgressIndicator(strokeWidth: 2)),
            ),
          ),
        if (!loading && points.isEmpty && liveLatLng == null && emptyHint != null)
          Positioned(
            left: 12,
            top: 12,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
              decoration: BoxDecoration(color: Colors.white.withValues(alpha: .92), borderRadius: BorderRadius.circular(9)),
              child: Text(emptyHint!, style: const TextStyle(color: plum, fontSize: 9, fontWeight: FontWeight.w800)),
            ),
          ),
      ]),
    );
  }

  Marker _pin(LatLng point, Color color, IconData icon) {
    return Marker(
      point: point,
      width: 34,
      height: 34,
      child: Container(
        decoration: BoxDecoration(color: Colors.white, shape: BoxShape.circle, border: Border.all(color: color, width: 3)),
        child: Icon(icon, color: color, size: 15),
      ),
    );
  }

  Marker _havenPin(Haven haven) {
    return Marker(
      point: haven.point,
      width: 26,
      height: 26,
      child: Tooltip(
        message: haven.name,
        child: Container(
          decoration: BoxDecoration(color: green, shape: BoxShape.circle, border: Border.all(color: Colors.white, width: 2)),
          child: Icon(haven.icon, color: Colors.white, size: 12),
        ),
      ),
    );
  }

  Marker _liveDot(LatLng point) {
    return Marker(
      point: point,
      width: 46,
      height: 46,
      child: Container(
        decoration: BoxDecoration(color: sosRed.withValues(alpha: .18), shape: BoxShape.circle),
        child: Center(
          child: Container(
            width: 18,
            height: 18,
            decoration: BoxDecoration(color: sosRed, shape: BoxShape.circle, border: Border.all(color: Colors.white, width: 3)),
          ),
        ),
      ),
    );
  }
}
