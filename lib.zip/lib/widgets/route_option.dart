import 'package:flutter/material.dart';

import '../models.dart';
import '../theme.dart';

class RouteOption extends StatelessWidget {
  const RouteOption({super.key, required this.route, required this.selected, required this.onTap, this.recommended = false});

  final SafeRoute route;
  final bool selected;
  final bool recommended;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        decoration: BoxDecoration(
          color: selected ? const Color(0xFFFFF9FA) : Colors.white,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: selected ? const Color(0xFFE3B4BF) : border),
        ),
        padding: const EdgeInsets.all(12),
        child: Row(children: [
          Container(width: 4, height: 62, decoration: BoxDecoration(color: route.color, borderRadius: BorderRadius.circular(2))),
          const SizedBox(width: 10),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                Text(route.name, style: const TextStyle(color: ink, fontSize: 13, fontWeight: FontWeight.w800)),
                if (recommended) ...[
                  const SizedBox(width: 6),
                  Container(
                    decoration: BoxDecoration(color: greenSoft, borderRadius: BorderRadius.circular(5)),
                    padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 3),
                    child: const Text('RECOMMENDED', style: TextStyle(color: green, fontSize: 7, fontWeight: FontWeight.w900, letterSpacing: .4)),
                  ),
                ],
              ]),
              const SizedBox(height: 4),
              Text('${route.subtitle} · ${route.distanceLabel} · ${route.durationLabel}', style: const TextStyle(color: muted, fontSize: 10)),
              const SizedBox(height: 8),
              Row(children: [
                const Icon(Icons.shield_outlined, color: green, size: 12),
                const SizedBox(width: 4),
                Text('${route.havens.length} havens nearby', style: const TextStyle(color: muted, fontSize: 9, fontWeight: FontWeight.w600)),
              ]),
            ]),
          ),
          const SizedBox(width: 5),
          Column(children: [
            Text('${route.safetyScore}', style: TextStyle(color: route.color, fontSize: 18, fontWeight: FontWeight.w800)),
            const Text('score', style: TextStyle(color: Color(0xFFA2949E), fontSize: 8, fontWeight: FontWeight.w700)),
          ]),
        ]),
      ),
    );
  }
}
